//
//  MTNewsTableViewCell.m
//  Matorin
//
//  Created by Work Inteleks on 9/4/17.
//

#import "MTNewsTableViewCell.h"
#import "MTNewsItem.h"
#import "NSString+Additions.h"
#import <SDWebImage/UIImageView+WebCache.h>

@interface MTNewsTableViewCell()
{
    IBOutlet UIImageView *pictureView;
    
    IBOutlet UILabel *dateLabel;
    IBOutlet UILabel *previewLabel;
}

@end

@implementation MTNewsTableViewCell

- (void)awakeFromNib
{
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

- (void)configureWithItem:(MTNewsItem *)item
                indexPath:(NSIndexPath *)indexPath
{
    if ([item.previewPic isNotEmpty])
    {
        [pictureView sd_setImageWithURL:[NSURL URLWithString:item.previewPic]
                       placeholderImage:[UIImage imageNamed:@"MT_news_placeholder"]
                                options:SDWebImageRefreshCached
                              completed:nil];
    }
    
    dateLabel.text = [item getNewsDate];
    
    previewLabel.text = item.name;
}

#pragma mark -

+ (NSString *)getCellIdentifier
{
    return @"NewsCell";
}

+ (MTNewsTableViewCell *)dequeueForTableView:(UITableView *)tableView
                                   indexPath:(NSIndexPath *)indexPath
                                        item:(MTNewsItem *)item
{
    MTNewsTableViewCell *cell = (MTNewsTableViewCell *)[tableView dequeueReusableCellWithIdentifier:[MTNewsTableViewCell getCellIdentifier]];
    
    if (!cell)
        cell = [[MTNewsTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                          reuseIdentifier:[MTNewsTableViewCell getCellIdentifier]];
    [cell configureWithItem:item
                  indexPath:indexPath];
    return cell;
}

@end
