//
//  MTUserObject.m
//  Matorin
//
//  Created by Oleg Bogatenko on 11/22/17.
//  Copyright © 2017 Matorin. All rights reserved.
//

#import "MTUserObject.h"

@implementation MTUserObject

@synthesize room;
@synthesize address;

+ (MTUserObject *)parseObjectInfoFromServerDict:(NSDictionary *)dict
{
    MTUserObject *obj = [MTUserObject new];
    
    obj.room = dict[@"Flatno"];
    obj.address = dict[@"Object_name"];
    
    return obj;
}

#pragma mark - Description

- (NSString *)description
{
    return [NSString stringWithFormat:@"OBJECT => %@ | %@",
            room,
            address];
}

@end
