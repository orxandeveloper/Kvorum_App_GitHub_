//
//  MTUser.h
//  Matorin
//
//  Created by Sergej Bogatenko on 11/17/17.
//  Copyright © 2017 Matorin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MTUserObject.h"

@interface MTUser : NSObject

@property (nonatomic) NSNumber *accountNumber;

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *phone;

@property (nonatomic, strong) MTUserObject *userObject;

+ (BOOL)isUserAuthorized;

+ (MTUser *)authorizedUserWithNumber:(NSNumber *)number
                             forDict:(NSDictionary *)dict;
+ (void)kill;

+ (MTUser *)loadCurrentUser;
+ (void)saveInUserDefaults:(MTUser *)user;

- (NSString *)getAuthToken;

- (void)setUserObjectInfoWithDict:(NSDictionary *)dict;

@end
