//
//  MTServiceYKCell.h
//  Matorin
//
//  Created by Work Inteleks on 9/18/17.
//

#import <UIKit/UIKit.h>

@class MTService;

@protocol MTServiceYKTableViewCellDelegate <NSObject>

@optional

- (void)checkServiceYK:(int)index add:(BOOL)add;
- (void)decreaseServiceYK:(int)index;
- (void)increaseServiceYK:(int)index;

@end

@interface MTServiceYKCell : UITableViewCell

+ (MTServiceYKCell *)dequeueForTableView:(UITableView *)tableView
                               indexPath:(NSIndexPath *)indexPath
                                delegate:(id <MTServiceYKTableViewCellDelegate>)delegate
                                 service:(MTService *)service;

@end
