//
//  MTServiceItem.h
//  Matorin
//
//  Created by Work Inteleks on 9/6/17.
//

#import <Foundation/Foundation.h>

@interface MTServiceItem : NSObject

@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *iconName;

@end
