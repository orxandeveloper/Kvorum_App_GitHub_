//
//  MTSideViewController.m
//  Matorin
//
//  Created by Work Inteleks on 8/31/17.
//

#import "MTSideViewController.h"

@interface MTSideViewController ()

@end

@implementation MTSideViewController

- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    
    if (self)
    {
        self.rootViewCoverAlphaForLeftView = 0.6f;
        self.leftViewAnimationDuration = 0.4f;
        self.rootViewLayerShadowColor = [UIColor colorWithWhite:0 alpha:0.6f];
        self.leftViewWidth = 284.f;
        self.leftViewPresentationStyle = LGSideMenuPresentationStyleSlideAbove;
        self.rootViewCoverColorForLeftView = [UIColor colorWithRed:0 green:0.1f blue:0 alpha:0.3f];
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)leftViewWillLayoutSubviewsWithSize:(CGSize)size
{
    [super leftViewWillLayoutSubviewsWithSize:size];
    
    if (!self.isLeftViewStatusBarHidden)
        self.leftView.frame = CGRectMake(0.0, 0.0, size.width, size.height);
}

- (BOOL)isLeftViewStatusBarHidden
{
    return super.isLeftViewStatusBarHidden;
}

@end
