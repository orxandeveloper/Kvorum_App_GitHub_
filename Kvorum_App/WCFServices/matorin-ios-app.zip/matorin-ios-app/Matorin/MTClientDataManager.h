//
//  MTClientDataManager.h
//  Matorin
//
//  Created by Work Inteleks on 9/5/17.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "MTUser.h"
#import "MTService.h"
#import "MTServiceDate.h"

#define CLIENT_DATA_MANAGER [MTClientDataManager sharedManager]

extern NSString * const MTAuthNotification;

@interface MTClientDataManager : NSObject

+ (MTClientDataManager *)sharedManager;

- (void)load;

- (BOOL)isOfferViewed;
- (void)setOfferAsViewed;

- (BOOL)isAuthorized;
- (NSString *)getUserAuthToken;

- (void)setUserAccountNumber:(NSNumber *)number
          infoFromServerDict:(NSDictionary *)dict;

- (NSString *)getUserFullName;
- (NSString *)getPersonalAccountNumber;
- (NSString *)getUserAddress;

- (void)setUserObjectInfoFromServerDict:(NSDictionary *)dict;

// Ordered Services
- (void)clearAllServicesInfo;

- (void)setUploadURL:(NSString *)urlString;
- (NSString *)getUploadURLString;

- (void)addOrderedService:(MTService *)service;
- (void)removeOrderedService:(MTService *)service;
- (void)clearOrderedServices;
- (NSArray<MTService *> *)getOrderedServices;
- (NSNumber *)getTotalPrice;

// Ordered Services Date
- (void)setupOrderedServicesDate:(MTServiceDate *)date;
- (MTServiceDate *)getOrderedServicesDate;
- (void)clearOrderedServicesDate;

// Ordered Comment/Files
- (void)setupServiceComment:(NSString *)comment;
- (NSString *)getServiceComment;
- (void)setupServiceImg:(UIImage *)img;
- (UIImage *)getServiceImg;
- (NSString *)getBase64ServiceImg;
- (NSArray *)getUploadImages;
- (void)setupOrderServiceNumber:(NSString *)number;
- (NSString *)getOrderServiceNumber;

@end
