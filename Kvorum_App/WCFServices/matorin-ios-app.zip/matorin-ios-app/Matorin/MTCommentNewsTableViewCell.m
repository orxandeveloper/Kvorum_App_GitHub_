//
//  MTCommentNewsTableViewCell.m
//  Matorin
//
//  Created by Work Inteleks on 9/12/17.
//

#import "MTCommentNewsTableViewCell.h"
#import "MTNewsCommentItem.h"

@interface MTCommentNewsTableViewCell()
{
    IBOutlet UILabel *authorCommentLabel;
    IBOutlet UILabel *textCommentLabel;
    IBOutlet UILabel *dateLabel;

    IBOutlet UIImageView *commentLogo;
}

@end

@implementation MTCommentNewsTableViewCell

- (void)awakeFromNib
{
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

#pragma mark -

- (void)configureWithItem:(MTNewsCommentItem *)item
                indexPath:(NSIndexPath *)indexPath
{
    
}

#pragma mark -

+ (NSString *)getCellIdentifier
{
    return @"CommentNewsCell";
}

+ (MTCommentNewsTableViewCell *)dequeueForTableView:(UITableView *)tableView
                                          indexPath:(NSIndexPath *)indexPath
                                               item:(MTNewsCommentItem *)item
{
    MTCommentNewsTableViewCell *cell = (MTCommentNewsTableViewCell *)[tableView dequeueReusableCellWithIdentifier:[MTCommentNewsTableViewCell getCellIdentifier]];
    
    if (!cell)
        cell = [[MTCommentNewsTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                                 reuseIdentifier:[MTCommentNewsTableViewCell getCellIdentifier]];
    [cell configureWithItem:item
                  indexPath:indexPath];
    return cell;
}

@end
