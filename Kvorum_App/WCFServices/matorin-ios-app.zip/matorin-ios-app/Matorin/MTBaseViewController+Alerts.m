//
//  UIViewController+Alerts.m
//  Matorin
//  Created by Oleg Bogatenko.
//

#import "MTBaseViewController+Alerts.h"

@implementation MTBaseViewController (Alerts)

- (void)showAlertWithTitle:(NSString *)title
                   message:(NSString *)message
{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(title, nil)
                                                                   message:NSLocalizedString(message, nil)
                                                            preferredStyle:UIAlertControllerStyleAlert];

    UIAlertAction *cancelButton = [UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil)
                                                           style:UIAlertActionStyleDefault
                                                         handler:^(UIAlertAction *action) {
                                                             
                                                             [alert dismissViewControllerAnimated:YES
                                                                                       completion:nil];
                                                         }];
    [alert addAction:cancelButton];
    
    [self presentViewController:alert
                       animated:YES
                     completion:nil];
}

- (void)showConnectionProblemAlert
{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil
                                                                   message:NSLocalizedString(@"No network", nil)
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *cancelButton = [UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil)
                                                           style:UIAlertActionStyleDefault
                                                         handler:^(UIAlertAction *action) {
                                                             
                                                             [alert dismissViewControllerAnimated:YES
                                                                                       completion:nil];
                                                         }];
    [alert addAction:cancelButton];
    
    [self presentViewController:alert
                       animated:YES
                     completion:nil];
}

@end
