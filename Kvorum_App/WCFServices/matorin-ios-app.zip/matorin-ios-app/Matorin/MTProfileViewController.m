//
//  MTProfileViewController.m
//  Matorin
//
//  Created by Work Inteleks on 9/5/17.
//

#import "MTProfileViewController.h"
#import "UIViewController+LGSideMenuController.h"
#import "MTClientDataManager.h"

@interface MTProfileViewController () <UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate>
{
    IBOutlet UILabel *addressLabel;
    
    IBOutlet UIButton *avatarBtn;
    
    IBOutlet UITextField *accountField;
    IBOutlet UITextField *phoneField;
    IBOutlet UITextField *clientNameField;
}

@end

@implementation MTProfileViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    phoneField.delegate = self;
    
    avatarBtn.layer.cornerRadius = 27.f;
    avatarBtn.clipsToBounds = YES;
    
    [self setupNavBar];
    [self setupClientInfo];
}

- (void)setupNavBar
{
    self.navigationItem.title = NSLocalizedString(@"Personal accounts", nil);
    
    UIButton *barBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    barBtn.bounds = CGRectMake( 0, 0, 22.f, 22.f );
    
    [barBtn addTarget:self
               action:@selector(showLeftViewAnimated:)
     forControlEvents:UIControlEventTouchUpInside];
    
    [barBtn setImage:[UIImage imageNamed:@"nav_burger_btn"] forState:UIControlStateNormal];
    
    UIBarButtonItem *menuBtn = [[UIBarButtonItem alloc] initWithCustomView:barBtn];
    
    self.navigationItem.leftBarButtonItem = menuBtn;
}

- (void)setupClientInfo
{
    addressLabel.text = [CLIENT_DATA_MANAGER getUserAddress];
    accountField.text = [CLIENT_DATA_MANAGER getPersonalAccountNumber];
    clientNameField.text = [CLIENT_DATA_MANAGER getUserFullName];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - Text Field Delegate

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField == phoneField)
    {
        NSUInteger currentLength = phoneField.text.length;
        
        NSCharacterSet *numbers = [NSCharacterSet decimalDigitCharacterSet];
        
        if (range.length == 1)
            return YES;
        
        if ([numbers characterIsMember:[string characterAtIndex:0]])
        {
            if ( currentLength == 3 )
            {
                if (range.length != 1)
                {
                    NSString *firstThreeDigits = [textField.text substringWithRange:NSMakeRange(0, 3)];
                    
                    NSString *updatedText;
                    
                    if ([string isEqualToString:@" "])
                        updatedText = [NSString stringWithFormat:@"%@",firstThreeDigits];
                    else
                        updatedText = [NSString stringWithFormat:@"%@ ",firstThreeDigits];
                    
                    [textField setText:updatedText];
                }
            }
            else if ( currentLength > 3 && currentLength < 8 )
            {
                if ( range.length != 1 )
                {
                    NSString *firstThree = [textField.text substringWithRange:NSMakeRange(0, 3)];
                    NSString *dash = [textField.text substringWithRange:NSMakeRange(3, 1)];
                    
                    NSUInteger newLenght = range.location - 4;
                    
                    NSString *nextDigits = [textField.text substringWithRange:NSMakeRange(4, newLenght)];
                    
                    NSString *updatedText = [NSString stringWithFormat:@"%@%@%@",firstThree,dash,nextDigits];
                    
                    [textField setText:updatedText];
                }
            }
            else if ( currentLength == 8 )
            {
                if ( range.length != 1 )
                {
                    NSString *areaCode = [textField.text substringWithRange:NSMakeRange(0, 3)];
                    
                    NSString *firstThree = [textField.text substringWithRange:NSMakeRange(4, 3)];
                    
                    NSString *nextDigit = [textField.text substringWithRange:NSMakeRange(7, 1)];
                    
                    [textField setText:[NSString stringWithFormat:@"(%@) %@ %@",areaCode,firstThree,nextDigit]];
                }
            }
        }
        else
        {
            return NO;
        }
        
        NSUInteger newLength = [textField.text length] + [string length] - range.length;
        return newLength <= 14;
    }
    
    return YES;
}

#pragma mark -

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

#pragma mark - Actions

- (IBAction)setAvatarAction:(id)sender
{
    return;
    
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil
                                                                   message:nil
                                                            preferredStyle:UIAlertControllerStyleActionSheet];
    
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Отменить"
                                                       style:UIAlertActionStyleCancel handler:^(UIAlertAction * action) {
                                                           
                                                       }];

    
    UIAlertAction *takePhotoAction = [UIAlertAction actionWithTitle:@"Сделать фото"
                                                       style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
                                                           [self takePhoto];
                                                          }];
    
    UIAlertAction *selectPhotoAction = [UIAlertAction actionWithTitle:@"Выбрать из галереи"
                                                       style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
                                                           [self selectPhoto];
                                                           }];
    
    UIAlertAction *removeAvatarAction = [UIAlertAction actionWithTitle:@"Удалить"
                                                       style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
                                                           [self removeAvatar];
                                                       }];
    
    [alert addAction:takePhotoAction];
    [alert addAction:selectPhotoAction];
    [alert addAction:removeAvatarAction];
    [alert addAction:cancelAction];
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)takePhoto
{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
    
    [self presentViewController:picker animated:YES completion:NULL];
}

- (void)selectPhoto
{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    
    [self presentViewController:picker animated:YES completion:NULL];
}

- (void)removeAvatar
{
    [avatarBtn setBackgroundImage:[UIImage imageNamed:@"placeholderAvatar"] forState:UIControlStateNormal];
    [avatarBtn setBackgroundImage:[UIImage imageNamed:@"placeholderAvatar"] forState:UIControlStateHighlighted];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *chosenImage = info[UIImagePickerControllerEditedImage];
    
    [avatarBtn setBackgroundImage:chosenImage forState:UIControlStateNormal];
    [avatarBtn setBackgroundImage:chosenImage forState:UIControlStateHighlighted];
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:YES completion:NULL];
}

@end
