//
//  MTUser.m
//  Matorin
//
//  Created by Sergej Bogatenko on 11/17/17.
//  Copyright © 2017 Matorin. All rights reserved.
//

#import "MTUser.h"
#import "NSString+Additions.h"

@interface MTUser ()
{
    @private
    NSString *tokenId;
}

@end

@implementation MTUser

@synthesize accountNumber;
@synthesize name;
@synthesize phone;
@synthesize userObject;

#pragma mark -

+ (BOOL)isUserAuthorized
{
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    return [[NSUserDefaults standardUserDefaults] boolForKey:@"user_authorized"];;
}

+ (void)setAuthorizedState
{
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"user_authorized"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+ (void)kill
{
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"user_authorized"];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"user"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

#pragma mark - Helpers

+ (void)saveInUserDefaults:(MTUser *)user
{
    NSData *encodedUser = [NSKeyedArchiver archivedDataWithRootObject:user];
    [[NSUserDefaults standardUserDefaults] setObject:encodedUser forKey:@"user"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+ (MTUser *)loadCurrentUser
{
    NSData *userData = [[NSUserDefaults standardUserDefaults] objectForKey:@"user"];
    
    if (userData)
        return (MTUser *)[NSKeyedUnarchiver unarchiveObjectWithData:userData];
    
    return nil;
}

#pragma mark - Serialization

- (void)encodeWithCoder:(NSCoder *)encoder
{
    [encoder encodeObject:tokenId forKey:@"tokenId"];
    
    [encoder encodeObject:name forKey:@"name"];
    [encoder encodeObject:phone forKey:@"phone"];
}

- (id)initWithCoder:(NSCoder *)decoder
{
    if (self = [super init])
    {
        self->tokenId = [decoder decodeObjectForKey:@"tokenId"];
        
        self.name  = [decoder decodeObjectForKey:@"name"];
        self.phone = [decoder decodeObjectForKey:@"phone"];
    }
    
    return self;
}

#pragma mark -

+ (MTUser *)authorizedUserWithNumber:(NSNumber *)number
                             forDict:(NSDictionary *)dict
{
    MTUser *user = [MTUser new];
    
    user.accountNumber = number;
    
    user->tokenId = dict[@"TokenId"];
    
    user.name = dict[@"Name"];
    user.phone = dict[@"Phone"];
    
    //[MTUser setAuthorizedState];
    
    return user;
}

#pragma mark -

- (NSString *)getAuthToken;
{
    return tokenId;
}

#pragma mark -

- (void)setUserObjectInfoWithDict:(NSDictionary *)dict
{
    
}

#pragma mark - Description

- (NSString *)description
{
    return [NSString stringWithFormat:@"USER => %@ | %@ | %@ | %@",
            name,
            phone,
            tokenId,
            userObject];
}

@end
