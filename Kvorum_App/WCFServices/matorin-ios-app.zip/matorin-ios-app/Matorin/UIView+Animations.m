//
//  UIView+Animations.m
//  Matorin
//
//  Created by Work Inteleks on 9/4/17.
//

#import "UIView+Animations.h"

@implementation UIView (Animations)

- (void)showViewWithAnimationInPoint:(CGPoint)point
{
    self.alpha = 0.0;
    
    self.transform = CGAffineTransformScale(self.transform, 0.01f, 0.01f);
    
    self.center = CGPointMake(self.frame.size.width / 2, self.frame.size.height / 2);
    
    [UIView animateWithDuration:0.2f delay:0.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        
        self.alpha = 1.0f;
        self.center = point;
        self.transform = CGAffineTransformScale(self.transform, 100.f, 100.f);
        
    } completion:nil];
}

- (void)hideViewWithAnimation
{
    [UIView animateWithDuration:0.2f delay:0.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        
        self.alpha = 0.0f;
        self.center = CGPointMake(self.frame.size.width / 2, self.frame.size.height / 2);
        self.transform = CGAffineTransformScale(self.transform, 0.01f, 0.01f);
        
    } completion:^(BOOL finished) {
        
        [self removeFromSuperview];
        
    }];
}

@end
