//
//  MTNavigationViewController.h
//  Matorin
//
//  Created by Work Inteleks on 8/31/17.
//

#import <UIKit/UIKit.h>

@interface MTNavigationViewController : UINavigationController

@end
