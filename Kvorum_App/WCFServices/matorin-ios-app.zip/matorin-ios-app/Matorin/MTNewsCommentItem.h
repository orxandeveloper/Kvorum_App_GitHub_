//
//  MTNewsCommentItem.h
//  Matorin
//
//  Created by Work Inteleks on 9/13/17.
//

#import <Foundation/Foundation.h>

@interface MTNewsCommentItem : NSObject

@property (nonatomic, copy) NSString *author;
@property (nonatomic, copy) NSString *textComment;
@property (nonatomic, copy) NSString *date;

@property (nonatomic, assign) BOOL showCommentLogo;

@end
