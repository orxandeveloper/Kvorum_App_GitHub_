//
//  NSString+Additions.h
//  Matorin
//
//  Created by Oleg Bogatenko on 8/30/17.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NSString (Additions)

- (BOOL)isNotEmpty;

- (NSAttributedString *)getAsHTMLAttributedStringWithFontSize:(float)fontSize;

- (NSAttributedString *)getAttributedStringWithFontSize:(float)fontSize paragraphStyle:(NSTextAlignment)paragraphStyle;

- (float)getTextWidth:(float)fontSize;

- (BOOL)isStringContainsValidEmail;

- (NSString *)convertToBase64String;

@end
