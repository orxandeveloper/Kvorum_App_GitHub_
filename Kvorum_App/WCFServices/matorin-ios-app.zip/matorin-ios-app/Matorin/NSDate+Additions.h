//
//  NSDate+Additions.h
//  Matorin
//
//  Created by Oleg Bogatenko on 11/23/17.
//  Copyright © 2017 Matorin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (Additions)

- (BOOL)isToday;

- (NSString *)getAsRedableString;

@end
