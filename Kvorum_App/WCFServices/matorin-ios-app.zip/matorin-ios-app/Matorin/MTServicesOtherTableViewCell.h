//
//  MTServicesOtherTableViewCell.h
//  Matorin
//
//  Created by Work Inteleks on 9/7/17.
//

#import <UIKit/UIKit.h>

@interface MTServicesOtherTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UIImageView *iconImageView;
@property (strong, nonatomic) IBOutlet UILabel *nameServicesLabel;
@property (strong, nonatomic) IBOutlet UILabel *addressServicesLabel;
@property (strong, nonatomic) IBOutlet UILabel *telServicesLabel;

@end
