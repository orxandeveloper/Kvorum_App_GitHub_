//
//  MTDetailsNewsTableViewCell.m
//  Matorin
//
//  Created by Work Inteleks on 9/4/17.
//

#import "MTDetailsNewsTableViewCell.h"
#import "MTNewsItem.h"
#import "NSString+Additions.h"
#import <SDWebImage/UIImageView+WebCache.h>

@interface MTDetailsNewsTableViewCell()
{
    IBOutlet UILabel *dateLabel;
    
    IBOutlet UILabel *textNewsLabel;
    
    IBOutlet UIImageView *imageNews;
    
    IBOutlet UIButton *commentBtn;
    IBOutlet UILabel *commentCountLabel;
    
    IBOutlet UIButton *likeBtn;
    IBOutlet UILabel *likeCountLabel;
    
    IBOutlet NSLayoutConstraint *newsLabelHeight;
    IBOutlet NSLayoutConstraint *imageHeight;
}

@property (nonatomic, weak) id <MTDetailsNewsTableViewCellDelegate> cellDelegate;

@end

@implementation MTDetailsNewsTableViewCell

@synthesize cellDelegate;

- (void)awakeFromNib
{
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

#pragma mark -

- (void)configureWithItem:(MTNewsItem *)item
                indexPath:(NSIndexPath *)indexPath
                 delegate:(id <MTDetailsNewsTableViewCellDelegate>)delegate
{
    cellDelegate = delegate;
    
    if ([item.detailPic isNotEmpty])
    {
        [imageNews sd_setImageWithURL:[NSURL URLWithString:item.detailPic]
                     placeholderImage:[UIImage imageNamed:@"MT_detail_news_placeholder"]
                              options:SDWebImageRefreshCached
                            completed:nil];
    }
    else
    {
        imageNews.hidden = YES;
        imageHeight.constant = 1.f;
    }
    
    dateLabel.text = [item getNewsDate];
    
    textNewsLabel.attributedText = [item.detailText getAsHTMLAttributedStringWithFontSize:15.f];
    
    [self returnCellHeight:item];
    [self tempHiddenUIElements];
}

- (void)tempHiddenUIElements
{
    likeBtn.hidden = YES;
    likeCountLabel.hidden = YES;
    
    commentBtn.hidden = YES;
    commentCountLabel.hidden = YES;
}

- (void)returnCellHeight:(MTNewsItem *)item
{
    // dateLabel Height
    float dateLabelHeight = dateLabel.frame.size.height;
    
    // textNewsLabel Height
    CGSize viewSize = [textNewsLabel sizeThatFits:CGSizeMake(textNewsLabel.frame.size.width, 1300.f)];
    float newsHeight = viewSize.height;
    newsLabelHeight.constant = newsHeight;
    
    // imageNews Height
    float imageNewsHeight = 0.f;
    if ([item.detailPic isNotEmpty])
        imageNewsHeight = imageNews.frame.size.height;
    
    // other Height
    float otherHeight = 75.f;
    
    float cellHeight = dateLabelHeight + newsHeight + imageNewsHeight + otherHeight;
    
    if (cellDelegate && [cellDelegate respondsToSelector:@selector(updateCellHeight:)])
        [cellDelegate updateCellHeight:cellHeight];
}

#pragma mark -

+ (NSString *)getCellIdentifier
{
    return @"DetailsNewsCell";
}

+ (MTDetailsNewsTableViewCell *)dequeueForTableView:(UITableView *)tableView
                                          indexPath:(NSIndexPath *)indexPath
                                           delegate:(id <MTDetailsNewsTableViewCellDelegate>)delegate
                                               item:(MTNewsItem *)item
{
    MTDetailsNewsTableViewCell *cell = (MTDetailsNewsTableViewCell *)[tableView dequeueReusableCellWithIdentifier:[MTDetailsNewsTableViewCell getCellIdentifier]];
    
    if (!cell)
        cell = [[MTDetailsNewsTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                                 reuseIdentifier:[MTDetailsNewsTableViewCell getCellIdentifier]];
    [cell configureWithItem:item
                  indexPath:indexPath
                   delegate:delegate];
    return cell;
}

@end
