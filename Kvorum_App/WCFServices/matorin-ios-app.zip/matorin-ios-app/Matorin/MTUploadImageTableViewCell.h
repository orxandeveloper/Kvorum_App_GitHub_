//
//  MTUploadImageTableViewCell.h
//  Matorin
//
//  Created by Sergej Bogatenko on 12/22/17.
//  Copyright © 2017 Matorin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MTUploadImageTableViewCell : UITableViewCell

+ (MTUploadImageTableViewCell *)dequeueForTableView:(UITableView *)tableView
                                          indexPath:(NSIndexPath *)indexPath
                                           imageUrl:(NSString *)imageUrl;

@end
