//
//  NSString+Additions.m
//  Matorin
//
//  Created by Oleg Bogatenko on 8/30/17.
//

#import "NSString+Additions.h"

@implementation NSString (Additions)

- (BOOL)isNotEmpty
{
    return [[self stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length] != 0;
}

- (NSAttributedString *)getAsHTMLAttributedStringWithFontSize:(float)fontSize
{
    UIFont *font = [UIFont systemFontOfSize:fontSize];
    
    NSMutableAttributedString *attrString = [[NSMutableAttributedString alloc] initWithData:[self dataUsingEncoding:NSUnicodeStringEncoding]
                                                                                    options:@{ NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType}
                                                                         documentAttributes:nil
                                                                                      error:nil];
    
    [attrString addAttribute:NSFontAttributeName
                       value:font
                       range:NSMakeRange(0, [attrString length])];
    
    return attrString;
}

- (NSAttributedString *)getAttributedStringWithFontSize:(float)fontSize paragraphStyle:(NSTextAlignment)paragraphStyle
{
    NSMutableAttributedString *attrString = [[NSMutableAttributedString alloc] initWithAttributedString:[self getAsHTMLAttributedStringWithFontSize:fontSize]];

    NSMutableParagraphStyle *paragraph = [[NSMutableParagraphStyle alloc] init];
    paragraph.alignment = paragraphStyle;
    
    [attrString addAttribute:NSParagraphStyleAttributeName
                       value:paragraph
                       range:NSMakeRange(0, [attrString length])];
    
    return attrString;
}

- (float)getTextWidth:(float)fontSize
{
    CGSize textSize = [self sizeWithAttributes:@{ NSFontAttributeName : [UIFont systemFontOfSize:fontSize] }];
    
    return textSize.width;
}

- (BOOL)isStringContainsValidEmail
{
    if ([self length] == 0)
        return NO;
    
    NSString *regExpPattern = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    
    NSRegularExpression *regEx = [[NSRegularExpression alloc] initWithPattern:regExpPattern
                                                                      options:NSRegularExpressionCaseInsensitive
                                                                        error:nil];
    return [@([regEx numberOfMatchesInString:self
                                     options:0
                                       range:NSMakeRange(0, [self length])]) boolValue];
}

- (NSString *)convertToBase64String
{
    NSData *descriptionData = [self dataUsingEncoding:NSUTF8StringEncoding];
    
    return [descriptionData base64EncodedStringWithOptions:0];
}

@end
