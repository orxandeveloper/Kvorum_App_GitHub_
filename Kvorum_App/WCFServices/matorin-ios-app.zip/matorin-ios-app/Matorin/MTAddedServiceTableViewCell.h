//
//  MTAddedServiceTableViewCell.h
//  Matorin
//
//  Created by Work Inteleks on 9/15/17.
//

#import <UIKit/UIKit.h>

@interface MTAddedServiceTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *numLabel;
@property (strong, nonatomic) IBOutlet UILabel *titleLabel;
@property (strong, nonatomic) IBOutlet UILabel *countLabel;
@property (strong, nonatomic) IBOutlet UILabel *priceLabel;

@end
