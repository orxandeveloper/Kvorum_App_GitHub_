//
//  MTRealizationServicesViewController.m
//  Matorin
//
//  Created by Work Inteleks on 9/11/17.
//

#import "MTRealizationServicesViewController.h"
#import "MTAddedServiceTableViewCell.h"
#import "MTChoiceServiceTableViewCell.h"
#import "MTClientDataManager.h"
#import "MTService.h"
#import "NSString+Additions.h"
#import "MTApiHelper.h"
#import "MTBaseViewController+Alerts.h"
#import "SVProgressHUD.h"
#import "UIView+Animations.h"
#import "MTUploadPreviewViewController.h"

@interface MTRealizationServicesViewController () <UITextViewDelegate, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITableViewDelegate, UITableViewDataSource, MTUploadPreviewViewControllerDelegate>
{
    MTUploadPreviewViewController *uploadPreview;
    
    UIView *backgroundView;
    
    IBOutlet UILabel *addressLabel;
    IBOutlet UILabel *accountLabel;
    
    IBOutlet UIView *totalContainerView;
    IBOutlet UIView *controllsContainerView;
    IBOutlet UIView *mainContainerView;

    IBOutlet UITextView *descriptionTextView;
    
    IBOutlet UIButton *addPhotoFileBtn;
    IBOutlet UIButton *showPhotoFileBtn;
    
    IBOutlet UITextField *phoneTextField;
    
    IBOutlet UIButton *selectTimeBtn;
    
    IBOutlet UITableView *choiceServicesTableView;
    
    IBOutlet UIButton *sendBtn;
    
    IBOutlet UILabel *dateLabel;
    
    IBOutlet UILabel *totalPriceLabel;
    
    UIImage *screenshot;
    
    IBOutlet UIView *dateSelectedContainer;
    IBOutlet UILabel *dateSelectedLabel;
    IBOutlet UILabel *timeSelectedLabel;
    
    float  mainContainerFrameOriginY;
    float  totalContainerFrameOriginY;
    float  controllsContainerFrameOriginY;
    float  dateSelectedContainerFrameOriginY;
}

@end

@implementation MTRealizationServicesViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self setupNavBar];
    [self setupAccountItems];
    
    descriptionTextView.layer.borderWidth = 1.0f;
    descriptionTextView.layer.borderColor = [UIColor colorWithRed:239.0/255.0 green:239.0/255.0 blue:244.0/255.0 alpha:1.0].CGColor;
    
    sendBtn.layer.borderWidth = 2.0f;
    sendBtn.layer.borderColor = [UIColor colorWithRed:239.0/255.0 green:239.0/255.0 blue:244.0/255.0 alpha:1.0].CGColor;
    sendBtn.layer.cornerRadius = 12.5;
    
    mainContainerFrameOriginY = mainContainerView.frame.origin.y;
    totalContainerFrameOriginY = totalContainerView.frame.origin.y;
    controllsContainerFrameOriginY = controllsContainerView.frame.origin.y;
    dateSelectedContainerFrameOriginY = dateSelectedContainer.frame.origin.y + [self getDateSelectedOffset];
}

- (float)getDateSelectedOffset
{
    if (IS_IPHONE_5)
        return 5.f;
        
    if (IS_IPHONE_6P)
        return 59.f;
    
    return 39.f;
}

- (void)setupAccountItems
{
    addressLabel.text = [CLIENT_DATA_MANAGER getUserAddress];
    accountLabel.text = [CLIENT_DATA_MANAGER getPersonalAccountNumber];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)setupNavBar
{
    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    self.navigationItem.title = NSLocalizedString(@"Выполнение работ", nil);
    
    UIBarButtonItem *back= [UIBarButtonItem new];
    back.title = NSLocalizedString(@"Назад", nil);
    self.navigationController.navigationBar.topItem.backBarButtonItem = back;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if ([CLIENT_DATA_MANAGER getOrderedServicesDate])
    {
        dateSelectedContainer.hidden = NO;
        dateSelectedLabel.text = [CLIENT_DATA_MANAGER getOrderedServicesDate].serviceDate;
        timeSelectedLabel.text = [NSString stringWithFormat:@"%@ - %@",
                                  [CLIENT_DATA_MANAGER getOrderedServicesDate].withServiceTime,
                                  [CLIENT_DATA_MANAGER getOrderedServicesDate].toServiceTime];
    }
    else
        dateLabel.text = NSLocalizedString(@"Указать удобное время выполнения", nil);
    
    [self changeTableViewFrame];
    
    [choiceServicesTableView reloadData];
}

- (void)changeTableViewFrame
{
    if (![CLIENT_DATA_MANAGER getOrderedServices].count)
        choiceServicesTableView.scrollEnabled = NO;
    else
        choiceServicesTableView.scrollEnabled = [CLIENT_DATA_MANAGER getOrderedServices].count > 3 ? YES : NO;

    if ([CLIENT_DATA_MANAGER getOrderedServices].count)
    {
        totalPriceLabel.text = [NSString stringWithFormat:@"%@", [CLIENT_DATA_MANAGER getTotalPrice]];;

        float heightTableView;

        if ([CLIENT_DATA_MANAGER getOrderedServices].count < 4)
        {
            if (IS_IPHONE_4_OR_LESS || IS_IPHONE_5)
                heightTableView = ([CLIENT_DATA_MANAGER getOrderedServices].count + 1) * 36;
            else if (IS_IPHONE_6)
                heightTableView = ([CLIENT_DATA_MANAGER getOrderedServices].count + 1) * 42;
            else
                heightTableView = ([CLIENT_DATA_MANAGER getOrderedServices].count + 1) * 46;
        }
        else
        {
            if (IS_IPHONE_4_OR_LESS || IS_IPHONE_5)
                heightTableView = 144;
            else if (IS_IPHONE_6)
                heightTableView = 168;
            else
                heightTableView = 184;
        }

        choiceServicesTableView.frame = CGRectMake(choiceServicesTableView.frame.origin.x,
                                                   choiceServicesTableView.frame.origin.y,
                                                   choiceServicesTableView.frame.size.width,
                                                   heightTableView);

        totalContainerView.frame = CGRectMake(totalContainerView.frame.origin.x,
                                              totalContainerFrameOriginY + heightTableView,
                                              totalContainerView.frame.size.width,
                                              totalContainerView.frame.size.height);

        controllsContainerView.frame = CGRectMake(controllsContainerView.frame.origin.x,
                                                  controllsContainerFrameOriginY + heightTableView,
                                                  controllsContainerView.frame.size.width,
                                                  controllsContainerView.frame.size.height);
        
        if (!dateSelectedContainer.isHidden)
            dateSelectedContainer.frame = CGRectMake(dateSelectedContainer.frame.origin.x,
                                                     dateSelectedContainerFrameOriginY + heightTableView - 3.f,
                                                     dateSelectedContainer.frame.size.width,
                                                     dateSelectedContainer.frame.size.height);
    }
    else
    {
        totalContainerView.frame = CGRectMake(totalContainerView.frame.origin.x,
                                              totalContainerFrameOriginY,
                                              totalContainerView.frame.size.width,
                                              totalContainerView.frame.size.height);

        controllsContainerView.frame = CGRectMake(controllsContainerView.frame.origin.x,
                                                  controllsContainerFrameOriginY,
                                                  controllsContainerView.frame.size.width,
                                                  controllsContainerView.frame.size.height);
        
        if (!dateSelectedContainer.isHidden)
            dateSelectedContainer.frame = CGRectMake(dateSelectedContainer.frame.origin.x,
                                                     dateSelectedContainerFrameOriginY - 3.f,
                                                     dateSelectedContainer.frame.size.width,
                                                     dateSelectedContainer.frame.size.height);
    }
}

#pragma mark - Text View Delegate

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if ([CLIENT_DATA_MANAGER getOrderedServices].count)
    {
        float keyboardValue;

        if (IS_IPHONE_6)
            keyboardValue = -20.0;
        else if (IS_IPHONE_6P)
            keyboardValue = -10.0;
        else
            keyboardValue = -100.0;

        [mainContainerView setFrame:CGRectMake(mainContainerView.frame.origin.x,
                                               keyboardValue,
                                               mainContainerView.frame.size.width,
                                               mainContainerView.frame.size.height)];
    }
    
    return YES;
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
    if ([CLIENT_DATA_MANAGER getOrderedServices].count)
    {
        [self.view setFrame:CGRectMake(mainContainerView.frame.origin.x,
                                       mainContainerFrameOriginY,
                                       self.view.frame.size.width,
                                       self.view.frame.size.height)];
    }

    return YES;
}

- (void)textViewDidBeginEditing:(UITextView *)textView
{
    if ([textView.text isEqualToString:NSLocalizedString(@"Добавить описание работ", nil)])
    {
        textView.text = @"";
        textView.textColor = [UIColor blackColor];
    }
    
    [textView becomeFirstResponder];
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
    if ([textView.text isEqualToString:@""])
    {
        textView.text = NSLocalizedString(@"Добавить описание работ", nil);
        textView.textColor = [UIColor colorWithRed:239.0/255.0 green:239.0/255.0 blue:244.0/255.0 alpha:1.0];
        [CLIENT_DATA_MANAGER setupServiceComment:nil];
    }
    
    if ([textView.text isNotEmpty] && ![textView.text isEqualToString:NSLocalizedString(@"Добавить описание работ", nil)])
    {
        [CLIENT_DATA_MANAGER setupServiceComment:textView.text];
    }
    
    [textView resignFirstResponder];
}

#pragma mark - Text Field Delegate

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField.tag == 3)
    {
        
        NSUInteger currentLength = phoneTextField.text.length;
        
        NSCharacterSet *numbers = [NSCharacterSet decimalDigitCharacterSet];
        
        if (range.length == 1)
            return YES;
        
        if ([numbers characterIsMember:[string characterAtIndex:0]])
        {
            if ( currentLength == 3 )
            {
                if (range.length != 1)
                {
                    NSString *firstThreeDigits = [textField.text substringWithRange:NSMakeRange(0, 3)];
                    
                    NSString *updatedText;
                    
                    if ([string isEqualToString:@" "])
                        updatedText = [NSString stringWithFormat:@"%@",firstThreeDigits];
                    else
                        updatedText = [NSString stringWithFormat:@"%@ ",firstThreeDigits];
                    
                    [textField setText:updatedText];
                }
            }
            else if ( currentLength > 3 && currentLength < 8 )
            {
                if ( range.length != 1 )
                {
                    
                    NSString *firstThree = [textField.text substringWithRange:NSMakeRange(0, 3)];
                    NSString *dash = [textField.text substringWithRange:NSMakeRange(3, 1)];
                    
                    NSUInteger newLenght = range.location - 4;
                    
                    NSString *nextDigits = [textField.text substringWithRange:NSMakeRange(4, newLenght)];
                    
                    NSString *updatedText = [NSString stringWithFormat:@"%@%@%@",firstThree,dash,nextDigits];
                    
                    [textField setText:updatedText];
                }
            }
            else if ( currentLength == 8 )
            {
                if ( range.length != 1 )
                {
                    NSString *areaCode = [textField.text substringWithRange:NSMakeRange(0, 3)];
                    
                    NSString *firstThree = [textField.text substringWithRange:NSMakeRange(4, 3)];
                    
                    NSString *nextDigit = [textField.text substringWithRange:NSMakeRange(7, 1)];
                    
                    [textField setText:[NSString stringWithFormat:@"(%@) %@ %@",areaCode,firstThree,nextDigit]];
                }
            }
        }
        else
        {
            return NO;
        }
        
        NSUInteger newLength = [textField.text length] + [string length] - range.length;
        return newLength <= 14;
    }
    
    return YES;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    
    if(touch.phase == UITouchPhaseBegan)
    {
        [descriptionTextView resignFirstResponder];
        [phoneTextField resignFirstResponder];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    
    return YES;
}

- (void)hideKeyboard
{
    [descriptionTextView resignFirstResponder];
    [phoneTextField resignFirstResponder];
}

#pragma mark - Dealoc

- (void)dealloc
{
    NSLog(@"dealloc");
    [CLIENT_DATA_MANAGER clearAllServicesInfo];
}

#pragma mark - MTUploadPreviewViewControllerDelegate

- (void)showUploadPreview
{
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    [self placeBackgoundView];
    
    if (!uploadPreview)
    {
        uploadPreview = [storyboard instantiateViewControllerWithIdentifier:@"MTUploadPreviewViewController"];
        
        uploadPreview.delegate = self;
        
        uploadPreview.view.frame = CGRectMake(([[UIScreen mainScreen] bounds].size.width - 300.f)/2,
                                              ([[UIScreen mainScreen] bounds].size.height - 500.f)/2,
                                              300.f, 500.f);
        
        [self.navigationController.view addSubview:uploadPreview.view];
        
        [uploadPreview.view showViewWithAnimationInPoint:CGPointMake([[UIScreen mainScreen] bounds].size.width / 2,
                                                                    [[UIScreen mainScreen] bounds].size.height / 2)];
    }
}

- (void)dismissPreview
{
    [uploadPreview.view hideViewWithAnimation];
    uploadPreview = nil;
    
    [self removeBackgoundView];
}

#pragma mark - Back View

- (void)placeBackgoundView
{
    backgroundView = [[UIView alloc] initWithFrame:CGRectMake(0, 0,
                                                              [[UIScreen mainScreen] bounds].size.width,
                                                              [[UIScreen mainScreen] bounds].size.height)];
    backgroundView.backgroundColor = [UIColor blackColor];
    backgroundView.alpha = 0;
    [self.navigationController.view addSubview:backgroundView];
    
    [UIView animateWithDuration:0.4f delay:0.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        backgroundView.alpha = 0.4f;
    } completion:nil];
}

- (void)removeBackgoundView
{
    [UIView animateWithDuration:0.4f delay:0.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        backgroundView.alpha = 0;
    } completion:^(BOOL finished){
        [backgroundView removeFromSuperview];
        backgroundView = nil;
    }];
}

#pragma mark - UIImagePickerControllerDelegate

- (void)imagePickerController:(UIImagePickerController *)picker
didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
{
    screenshot = info[UIImagePickerControllerOriginalImage];
    
    if (screenshot)
    {
        [CLIENT_DATA_MANAGER setupServiceImg:screenshot];
        
        [self performSelector:@selector(uploadFile) withObject:nil afterDelay:0.5f];
    }
    
    [picker dismissViewControllerAnimated:YES
                               completion:nil];
}

#pragma mark - Action

- (IBAction)selectPhoto:(id)sender
{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    
    [self presentViewController:picker
                       animated:YES
                     completion:NULL];
}

- (IBAction)showImages:(id)sender
{
    if ([CLIENT_DATA_MANAGER getUploadImages].count)
        [self showUploadPreview];
}

- (IBAction)sendPressed:(id)sender
{
    if ([CLIENT_DATA_MANAGER getOrderedServices].count &&
        [[CLIENT_DATA_MANAGER getOrderedServicesDate].serviceDate isNotEmpty] &&
        [[CLIENT_DATA_MANAGER getUploadURLString] isNotEmpty] &&
        [[CLIENT_DATA_MANAGER getServiceComment] isNotEmpty] &&
        [[NSString stringWithFormat:@"%@", phoneTextField.text] isNotEmpty])
    {
        NSMutableDictionary *requestParam = [NSMutableDictionary new];
        [requestParam setObject:[CLIENT_DATA_MANAGER getOrderedServices][0].kGUID forKey:@"work_kind"];
        [requestParam setObject:[NSString stringWithFormat:@"%@", phoneTextField.text] forKey:@"phone_number"];
        [requestParam setObject:[[NSString stringWithFormat:@"%@", [CLIENT_DATA_MANAGER getServiceComment]] convertToBase64String] forKey:@"description"];
        [requestParam setObject:[[CLIENT_DATA_MANAGER getOrderedServicesDate] getServiceDate] forKey:@"workdate"];
        [requestParam setObject:[[CLIENT_DATA_MANAGER getOrderedServicesDate] getWithServiceTime] forKey:@"workbegin"];
        [requestParam setObject:[[CLIENT_DATA_MANAGER getOrderedServicesDate] getToServiceTime] forKey:@"workend"];
        [requestParam setObject:[CLIENT_DATA_MANAGER getOrderedServices][0].work_kind forKey:@"destination"];
        [requestParam setObject:[[CLIENT_DATA_MANAGER getUploadURLString] convertToBase64String] forKey:@"files"];

        [self orderServiceRequestWithParam:requestParam];
    }
    else
        [self showAlertWithTitle:nil
                         message:NSLocalizedString(@"Please enter details", nil)];
}

#pragma mark - Table View

- (void)orderServiceRequestWithParam:(NSDictionary *)param
{
    __weak __typeof(self)weakSelf = self;
    
    [SVProgressHUD show];
    
    [API_HELPER addOperationWithType:MTApiOpAddNewServiceRequest
                              params:param
                             connect:^(BOOL state) {
                                 
                                 if (!state)
                                 {
                                     [SVProgressHUD dismiss];
                                     [weakSelf showConnectionProblemAlert];
                                 }
                                 
                             } completion:^(BOOL status, id data, NSString *reason) {
                                 
                                 if (status)
                                     [weakSelf processServerData:(NSDictionary *)data];
                                 else
                                 {
                                     [SVProgressHUD dismiss];
                                     
                                     [weakSelf showAlertWithTitle:NSLocalizedString(@"Error", nil)
                                                          message:reason];
                                 }
                             }];
}

- (void)processServerData:(NSDictionary *)dict
{
    [SVProgressHUD dismiss];
    
    MTServerResponse *resp = [MTServerResponse parseServerAnswer:dict
                                                          opType:MTApiOpAddNewServiceRequest];
    if ([resp isSuccessResponse])
    {
        [CLIENT_DATA_MANAGER setupOrderServiceNumber:[resp getResponseData][@"NUMBER"]];

        [self pushToCompleteServicesController];
    }
    else
        [self showAlertWithTitle:NSLocalizedString(@"Error", nil)
                         message:[resp getReasonMessage]];
}

- (void)pushToCompleteServicesController
{
    MTRealizationServicesViewController *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"MTCompleteServicesViewController"];
    [self.navigationController pushViewController:controller animated:YES];
}

- (void)uploadFile
{
    __weak __typeof(self)weakSelf = self;
    
    [SVProgressHUD show];
    
    NSDictionary *param = @{ @"file" : [CLIENT_DATA_MANAGER getServiceImg],
                             @"sign" : @"1" }; //Признак файла: 1-вложение, 2-фото в профиле

    [API_HELPER addOperationWithType:MTApiOpUploadFile
                              params:param
                             connect:^(BOOL state) {
                                 
                                 if (!state)
                                 {
                                     [SVProgressHUD dismiss];
                                     [weakSelf showConnectionProblemAlert];
                                 }
                                 
                             } completion:^(BOOL status, id data, NSString *reason) {
                                 
                                 if (status)
                                     [weakSelf processUploadServerData:(NSDictionary *)data];
                                 else
                                 {
                                     [SVProgressHUD dismiss];
                                     
                                     [weakSelf showAlertWithTitle:NSLocalizedString(@"Error", nil)
                                                          message:reason];
                                 }
                             }];
}

- (void)processUploadServerData:(NSDictionary *)dict
{
    [SVProgressHUD dismiss];
    
    [CLIENT_DATA_MANAGER setUploadURL:dict[@"URL"]];
    
//    MTServerResponse *resp = [MTServerResponse parseServerAnswer:dict
//                                                          opType:MTApiOpUploadFile];
//    if ([resp isSuccessResponse])
//    {
//        NSLog(@"isSuccessResponse");
//        //[CLIENT_DATA_MANAGER setupOrderServiceNumber:[resp getResponseData][@"URL"]];
//    }
//    else
//        [self showAlertWithTitle:NSLocalizedString(@"Error", nil)
//                         message:[resp getReasonMessage]];
    
    NSLog(@"dict %@", dict);
}

#pragma mark - Table View

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [CLIENT_DATA_MANAGER getOrderedServices].count ? [CLIENT_DATA_MANAGER getOrderedServices].count + 1 : 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (IS_IPHONE_4_OR_LESS || IS_IPHONE_5)
        return 36;
    else if (IS_IPHONE_6)
        return 42;
    else if (IS_IPHONE_6P)
        return 46;
    
    return 36;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([CLIENT_DATA_MANAGER getOrderedServices].count)
    {
        if (indexPath.row == [CLIENT_DATA_MANAGER getOrderedServices].count)
        {
            MTChoiceServiceTableViewCell *cell = (MTChoiceServiceTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"ChoiceServiceCell"];

            if (!cell)
                cell = [[MTChoiceServiceTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                                          reuseIdentifier:@"ChoiceServiceCell"];

            return cell;
        }
        else
        {
            MTAddedServiceTableViewCell *cell = (MTAddedServiceTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"AddedServiceCell"];

            if (!cell)
                cell = [[MTAddedServiceTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                                         reuseIdentifier:@"AddedServiceCell"];

            MTService *object = [CLIENT_DATA_MANAGER getOrderedServices][indexPath.row];

            cell.numLabel.text = [NSString stringWithFormat:@"%ld", (long)indexPath.row + 1];
            cell.titleLabel.text = object.work_kind;
            cell.countLabel.text = [NSString stringWithFormat:@"%i", object.count];
            cell.priceLabel.text = [NSString stringWithFormat:@"%@", object.price];
            
            cell.countLabel.hidden = YES;
            cell.priceLabel.hidden = YES;

            return cell;
        }
    }
    else
    {
        MTChoiceServiceTableViewCell *cell = (MTChoiceServiceTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"ChoiceServiceCell"];

        if (!cell)
            cell = [[MTChoiceServiceTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                                      reuseIdentifier:@"ChoiceServiceCell"];

        return cell;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(nonnull NSIndexPath *)indexPath
{
    [self hideKeyboard];
    
    MTRealizationServicesViewController *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"MTChoiceServicesViewController"];
    [self.navigationController pushViewController:controller animated:YES];
}

- (IBAction)setDate:(id)sender
{
    [self hideKeyboard];
    
    MTRealizationServicesViewController *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"MTSelectDateServicesViewController"];
    [self.navigationController pushViewController:controller animated:YES];
}

@end
