//
//  MTServicesOtherViewController.m
//  Matorin
//
//  Created by Work Inteleks on 9/6/17.
//

#import "MTServicesOtherViewController.h"
#import "UIViewController+LGSideMenuController.h"
#import "MTServicesOtherTableViewCell.h"

@interface MTServicesOtherViewController () <UITableViewDelegate, UITableViewDataSource>
{
    IBOutlet UITableView *servicesTableView;
}

@end

@implementation MTServicesOtherViewController

@synthesize titleNavBar;

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self setupMenuBarButtons];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)setupMenuBarButtons
{
    self.navigationItem.title = NSLocalizedString(titleNavBar, nil);
    
    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    
    UIBarButtonItem *back= [UIBarButtonItem new];
    back.title = NSLocalizedString(@"Назад", nil);
    self.navigationController.navigationBar.topItem.backBarButtonItem = back;
}

#pragma mark - Table View

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (IS_IPHONE_4_OR_LESS || IS_IPHONE_5)
        return 94.f;
    else if (IS_IPHONE_6)
        return 110.f;
    else if (IS_IPHONE_6P)
        return 120.f;
    
    return 94.f;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
        MTServicesOtherTableViewCell *cell = (MTServicesOtherTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"ServicesOtherCell"];
        
        if (!cell)
            cell = [[MTServicesOtherTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                                       reuseIdentifier:@"ServicesOtherCell"];
    
        return cell;
}

@end
