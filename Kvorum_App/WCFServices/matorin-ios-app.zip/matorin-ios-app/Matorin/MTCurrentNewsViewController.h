//
//  MTCurrentNewsViewController.h
//  Matorin
//
//  Created by Work Inteleks on 9/4/17.
//

#import "MTBaseViewController.h"

@class MTNewsItem;

@interface MTCurrentNewsViewController : MTBaseViewController

- (void)setNewsItem:(MTNewsItem *)item;

@end
