//
//  MTNewsTableViewCell.h
//  Matorin
//
//  Created by Work Inteleks on 9/4/17.
//

#import <UIKit/UIKit.h>

@class MTNewsItem;

@interface MTNewsTableViewCell : UITableViewCell

+ (MTNewsTableViewCell *)dequeueForTableView:(UITableView *)tableView
                                   indexPath:(NSIndexPath *)indexPath
                                        item:(MTNewsItem *)item;

@end
