//
//  MTOrderServicesViewController.m
//  Matorin
//
//  Created by Work Inteleks on 9/6/17.
//

#import "MTOrderServicesViewController.h"
#import "MTServiceItem.h"
#import "MTOrderServicesTableViewCell.h"
#import "UIViewController+LGSideMenuController.h"
#import "MTServicesYKViewController.h"
#import "MTServicesOtherViewController.h"

@interface MTOrderServicesViewController () <UITableViewDelegate, UITableViewDataSource>
{
    IBOutlet UITableView *servicesTableView;
    
    NSArray <MTServiceItem *> *serviceItems;
}

@end

@implementation MTOrderServicesViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self setupServiceItems];
    
    [self setupMenuBarButtons];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)setupMenuBarButtons
{
    self.navigationItem.title = NSLocalizedString(@"Заказать услугу", nil);
    
    UIButton *barBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    barBtn.bounds = CGRectMake( 0.0, 0.0, 22.0, 22.0 );
    
    [barBtn addTarget:self
               action:@selector(showLeftViewAnimated:)
     forControlEvents:UIControlEventTouchUpInside];
    
    [barBtn setImage:[UIImage imageNamed:@"nav_burger_btn"] forState:UIControlStateNormal];
    
    UIBarButtonItem *menuBtn = [[UIBarButtonItem alloc] initWithCustomView:barBtn];
    
    self.navigationItem.leftBarButtonItem = menuBtn;
}

- (void)setupServiceItems
{
    MTServiceItem *item1 = [MTServiceItem new];
    item1.title = NSLocalizedString(@"Все для дома", nil);
    item1.iconName = @"Service_1";
    
    MTServiceItem *item2 = [MTServiceItem new];
    item2.title = NSLocalizedString(@"Страхование и юр. услуги", nil);
    item2.iconName = @"Service_2";
    
    MTServiceItem *item3 = [MTServiceItem new];
    item3.title = NSLocalizedString(@"Еда", nil);
    item3.iconName = @"Service_3";
    
    MTServiceItem *item4 = [MTServiceItem new];
    item4.title = NSLocalizedString(@"Для авто", nil);
    item4.iconName = @"Service_4";
    
    MTServiceItem *item5 = [MTServiceItem new];
    item5.title = NSLocalizedString(@"Красота, здоровье, спорт", nil);
    item5.iconName = @"Service_5";
    
    MTServiceItem *item6 = [MTServiceItem new];
    item6.title = NSLocalizedString(@"Домашние животные", nil);
    item6.iconName = @"Service_6";
    
    MTServiceItem *item7 = [MTServiceItem new];
    item7.title = NSLocalizedString(@"Образование", nil);
    item7.iconName = @"Service_7";
    
    MTServiceItem *item8 = [MTServiceItem new];
    item8.title = NSLocalizedString(@"Организация мероприятий", nil);
    item8.iconName = @"Service_8";
    
    MTServiceItem *item9 = [MTServiceItem new];
    item9.title = NSLocalizedString(@"Услуги ук", nil);
    item9.iconName = @"Service_9";
    
    MTServiceItem *item10 = [MTServiceItem new];
    item10.title = NSLocalizedString(@"Госуслуги", nil);
    item10.iconName = @"Service_10";
    
    serviceItems = @[item1, item2, item3, item4, item5, item6, item7, item8, item9, item10];
}

#pragma mark - Table View

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return serviceItems.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (IS_IPHONE_4_OR_LESS || IS_IPHONE_5)
        return 55.0;
    else if (IS_IPHONE_6)
        return 66.0;
    else if (IS_IPHONE_6P)
        return 72.0;
    
    return 55.0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MTOrderServicesTableViewCell *cell = (MTOrderServicesTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"OrderServicesCell"];
    
    if (!cell)
        cell = [[MTOrderServicesTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                         reuseIdentifier:@"OrderServicesCell"];
    
    cell.titleServicesLabel.text = serviceItems[indexPath.row].title;
    cell.iconImageView.image = [UIImage imageNamed:serviceItems[indexPath.row].iconName];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(nonnull NSIndexPath *)indexPath
{
    if (indexPath.row == 8)
    {
        MTServicesYKViewController *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"MTServicesYKViewController"];
    
        [self.navigationController pushViewController:controller
                                             animated:YES];
    }
    else
    {
        MTServicesOtherViewController *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"MTServicesOtherViewController"];
        
        controller.titleNavBar = serviceItems[indexPath.row].title;
        
        [self.navigationController pushViewController:controller
                                             animated:YES];
    }
}

@end
