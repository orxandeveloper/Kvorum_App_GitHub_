//
//  MTNewsViewController.h
//  Matorin
//
//  Created by Work Inteleks on 8/31/17.
//

#import "MTBaseViewController.h"

@interface MTNewsViewController : MTBaseViewController

@end
