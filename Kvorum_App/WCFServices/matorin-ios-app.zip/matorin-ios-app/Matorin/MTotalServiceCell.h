//
//  MTotalServiceCell.h
//  Matorin
//
//  Created by Work Inteleks on 9/18/17.
//

#import <UIKit/UIKit.h>

@interface MTotalServiceCell : UITableViewCell

+ (MTotalServiceCell *)dequeueForTableView:(UITableView *)tableView
                                 indexPath:(NSIndexPath *)indexPath
                                     price:(NSString *)price;

@end
