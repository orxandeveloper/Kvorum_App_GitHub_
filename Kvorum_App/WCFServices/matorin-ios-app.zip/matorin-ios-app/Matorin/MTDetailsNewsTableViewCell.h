//
//  MTDetailsNewsTableViewCell.h
//  Matorin
//
//  Created by Work Inteleks on 9/4/17.
//

#import <UIKit/UIKit.h>

@class MTNewsItem;

@protocol MTDetailsNewsTableViewCellDelegate <NSObject>

@optional
- (void)updateCellHeight:(float)height;
@end

@interface MTDetailsNewsTableViewCell : UITableViewCell

+ (MTDetailsNewsTableViewCell *)dequeueForTableView:(UITableView *)tableView
                                          indexPath:(NSIndexPath *)indexPath
                                           delegate:(id <MTDetailsNewsTableViewCellDelegate>)delegate
                                               item:(MTNewsItem *)item;
@end
