//
//  MTMenuTableViewCell.m
//  Matorin
//
//  Created by Work Inteleks on 8/31/17.
//

#import "MTMenuTableViewCell.h"
#import "MTMenuItem.h"

@interface MTMenuTableViewCell ()
{
    IBOutlet UIImageView *menuIcon;
    
    IBOutlet UILabel *titleLabel;
    IBOutlet UILabel *countLabel;
}

@end

@implementation MTMenuTableViewCell

- (void)awakeFromNib
{
    [super awakeFromNib];
}

#pragma mark -

- (void)setHighlighted:(BOOL)highlighted animated:(BOOL)animated
{
    [super setHighlighted:highlighted animated:animated];
    
    countLabel.backgroundColor = [UIColor whiteColor];
}

#pragma mark -

- (void)drawRect:(CGRect)rect
{
    countLabel.layer.cornerRadius  = countLabel.frame.size.height/2.f;
    countLabel.layer.masksToBounds = YES;
}

#pragma mark -

- (void)configureWithItem:(MTMenuItem *)item
                indexPath:(NSIndexPath *)indexPath
{
    titleLabel.text = item.title;
    
    menuIcon.image = [UIImage imageNamed:item.iconName];

    if (item.showCountLabel)
        countLabel.text = item.countText;
    else
        countLabel.hidden = YES;
}

#pragma mark -

+ (NSString *)getCellIdentifier
{
    return @"MenuCell";
}

+ (MTMenuTableViewCell *)dequeueForTableView:(UITableView *)tableView
                                   indexPath:(NSIndexPath *)indexPath
                                        item:(MTMenuItem *)item
{
    MTMenuTableViewCell *cell = (MTMenuTableViewCell *)[tableView dequeueReusableCellWithIdentifier:[MTMenuTableViewCell getCellIdentifier]];
    
    if (!cell)
        cell = [[MTMenuTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                          reuseIdentifier:[MTMenuTableViewCell getCellIdentifier]];
    
    [cell configureWithItem:item
                  indexPath:indexPath];
    return cell;
}

@end
