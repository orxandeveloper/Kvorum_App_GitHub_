//
//  MTAddedServiceTableViewCell.m
//  Matorin
//
//  Created by Work Inteleks on 9/15/17.
//

#import "MTAddedServiceTableViewCell.h"

@implementation MTAddedServiceTableViewCell

@synthesize numLabel;
@synthesize titleLabel;
@synthesize countLabel;
@synthesize priceLabel;

- (void)awakeFromNib
{
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

@end
