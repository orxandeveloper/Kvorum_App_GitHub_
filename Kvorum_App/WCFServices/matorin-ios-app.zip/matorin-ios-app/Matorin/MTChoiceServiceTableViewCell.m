//
//  MTChoiceServiceTableViewCell.m
//  Matorin
//
//  Created by Work Inteleks on 9/15/17.
//

#import "MTChoiceServiceTableViewCell.h"

@implementation MTChoiceServiceTableViewCell

@synthesize addIcon;
@synthesize titleLabel;

- (void)awakeFromNib
{
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

@end
