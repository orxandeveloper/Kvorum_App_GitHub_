//
//  NSDate+Additions.m
//  Matorin
//
//  Created by Oleg Bogatenko on 11/23/17.
//  Copyright © 2017 Matorin. All rights reserved.
//

#import "NSDate+Additions.h"

@implementation NSDate (Additions)

- (BOOL)isToday
{
    return [[NSCalendar currentCalendar] isDateInToday:self];
}

- (NSString *)getAsRedableString
{
    NSDateFormatter *dateFormatter = [NSDateFormatter new];
    
    if ([self isToday])
    {
        dateFormatter.dateFormat = @"HH:mm";
        return [NSString stringWithFormat:@"%@ %@",
                NSLocalizedString(@"today", nil),
                [dateFormatter stringFromDate:self]];
    }
    
    dateFormatter.dateFormat = @"YYYY-MM-dd HH:mm";
    return [dateFormatter stringFromDate:self];
}

@end
