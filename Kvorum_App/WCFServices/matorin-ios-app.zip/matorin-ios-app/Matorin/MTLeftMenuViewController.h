//
//  MTLeftMenuViewController.h
//  Matorin
//
//  Created by Work Inteleks on 8/31/17.
//

#import <UIKit/UIKit.h>

@interface MTLeftMenuViewController : UIViewController

@end
