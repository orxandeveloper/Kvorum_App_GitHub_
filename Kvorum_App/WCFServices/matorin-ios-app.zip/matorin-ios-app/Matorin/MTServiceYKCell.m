//
//  MTServiceYKCell.m
//  Matorin
//
//  Created by Work Inteleks on 9/18/17.
//

#import "MTServiceYKCell.h"
#import "MTService.h"

@interface MTServiceYKCell()
{
    IBOutlet UILabel *nameServiceLabel;
    
    IBOutlet UIView *countContainerView;
    IBOutlet UILabel *countLabel;
    IBOutlet UIButton *increaseBtn;
    IBOutlet UIButton *decreaseBtn;
    
    IBOutlet UILabel *priceServiceLabel;
    
    IBOutlet UIButton *checkBtn;
    
    int count;
}

@property (nonatomic, weak) id <MTServiceYKTableViewCellDelegate> cellDelegate;

- (IBAction)checkService:(UIButton *)sender;
- (IBAction)decreaseService:(UIButton *)sender;
- (IBAction)increaseService:(UIButton *)sender;

@end

@implementation MTServiceYKCell

@synthesize cellDelegate;

- (void)awakeFromNib
{
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

#pragma mark - Action

- (void)checkService:(UIButton *)sender
{
    sender.selected = !sender.isSelected;
    
    if (cellDelegate && [cellDelegate respondsToSelector:@selector(checkServiceYK:add:)])
        [cellDelegate checkServiceYK:(int)sender.tag add:sender.isSelected];
}

- (void)decreaseService:(UIButton *)sender
{
    count--;
    if (count < 1)
        count = 1;
    countLabel.text = [NSString stringWithFormat:@"%i", count];

    if (cellDelegate && [cellDelegate respondsToSelector:@selector(decreaseServiceYK:)])
        [cellDelegate decreaseServiceYK:(int)sender.tag];
}

- (void)increaseService:(UIButton *)sender
{
    count++;
    countLabel.text = [NSString stringWithFormat:@"%i", count];
    
    if (cellDelegate && [cellDelegate respondsToSelector:@selector(increaseServiceYK:)])
        [cellDelegate increaseServiceYK:(int)sender.tag];
}

#pragma mark - Configure Cell

- (void)configureWithService:(MTService *)service
                    delegate:(id <MTServiceYKTableViewCellDelegate>)delegate
                   indexPath:(NSIndexPath *)indexPath
{
    cellDelegate = delegate;
    
    nameServiceLabel.text = service.work_kind;
    countContainerView.hidden = !service.showCountBtns;
    
    count = service.count;
    countLabel.text = [NSString stringWithFormat:@"%i", count];
    priceServiceLabel.text = [NSString stringWithFormat:@"%@", service.price]; 
    
    checkBtn.selected = service.isCheck;
    
    checkBtn.tag    = indexPath.row;
    decreaseBtn.tag = indexPath.row;
    increaseBtn.tag = indexPath.row;
    
    [self tempHiddenUIElements];
}

- (void)tempHiddenUIElements
{
    countLabel.hidden = YES;
    priceServiceLabel.hidden = YES;
    
    decreaseBtn.hidden = YES;
    increaseBtn.hidden = YES;
}

#pragma mark -

+ (NSString *)getCellIdentifier
{
    return @"ServiceYKCell";
}

+ (MTServiceYKCell *)dequeueForTableView:(UITableView *)tableView
                               indexPath:(NSIndexPath *)indexPath
                                delegate:(id <MTServiceYKTableViewCellDelegate>)delegate
                                 service:(MTService *)service
{
    MTServiceYKCell *cell = (MTServiceYKCell *)[tableView dequeueReusableCellWithIdentifier:[MTServiceYKCell getCellIdentifier]];
    
    if (!cell)
        cell = [[MTServiceYKCell alloc] initWithStyle:UITableViewCellStyleDefault
                                      reuseIdentifier:[MTServiceYKCell getCellIdentifier]];
    
    [cell configureWithService:service
                      delegate:delegate
                     indexPath:indexPath];
    
    return cell;
}

@end
