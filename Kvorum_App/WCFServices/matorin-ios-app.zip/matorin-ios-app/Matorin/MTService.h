//
//  MTService.h
//  Matorin
//
//  Created by Sergej Bogatenko on 11/24/17.
//  Copyright © 2017 Matorin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MTService : NSObject

@property (nonatomic, copy) NSString *kGUID;      //kGUID
@property (nonatomic, copy) NSString *work_kind;  //WORK_KIND

@property (nonatomic, assign) BOOL visible;       //VISIBLE

@property (nonatomic, assign) BOOL showCountBtns; //API not return
@property (nonatomic) NSNumber *price;            //API not return

@property (nonatomic, assign) u_int count;
@property (nonatomic, assign) BOOL isCheck;

+ (NSArray <MTService *> *)parseServiceFromDict:(NSDictionary *)dict
                                    onlyVisible:(BOOL)onlyVisible;

@end
