//
//  MTServiceDate.h
//  Matorin
//
//  Created by Sergej Bogatenko on 11/24/17.
//  Copyright © 2017 Matorin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MTServiceDate : NSObject

@property (nonatomic, copy) NSString *serviceDate;
@property (nonatomic, copy) NSString *withServiceTime;
@property (nonatomic, copy) NSString *toServiceTime;

- (NSString *)getServiceDate;
- (NSString *)getWithServiceTime;
- (NSString *)getToServiceTime;

@end
