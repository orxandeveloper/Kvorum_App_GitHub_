//
//  MTChoiceServiceTableViewCell.h
//  Matorin
//
//  Created by Work Inteleks on 9/15/17.
//

#import <UIKit/UIKit.h>

@interface MTChoiceServiceTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UIImageView *addIcon;
@property (strong, nonatomic) IBOutlet UILabel *titleLabel;

@end
