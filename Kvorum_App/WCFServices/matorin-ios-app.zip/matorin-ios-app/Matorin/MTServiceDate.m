//
//  MTServiceDate.m
//  Matorin
//
//  Created by Sergej Bogatenko on 11/24/17.
//  Copyright © 2017 Matorin. All rights reserved.
//

#import "MTServiceDate.h"

@implementation MTServiceDate

@synthesize serviceDate;
@synthesize withServiceTime;
@synthesize toServiceTime;

- (NSString *)getServiceDate
{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"dd.MM.yyyy"];
    NSDate *date = [dateFormat dateFromString:serviceDate];
    
    return [dateFormat stringFromDate:date];
}

- (NSString *)getWithServiceTime
{
    return [withServiceTime stringByReplacingOccurrencesOfString:@" : " withString:@"-"];
}

- (NSString *)getToServiceTime
{
    return [toServiceTime stringByReplacingOccurrencesOfString:@" : " withString:@"-"];
}

@end
