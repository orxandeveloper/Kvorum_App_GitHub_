//
//  MTCurrentNewsViewController.m
//  Matorin
//
//  Created by Work Inteleks on 9/4/17.
//

#import "MTCurrentNewsViewController.h"
#import "MTDetailsNewsTableViewCell.h"
#import "MTClientDataManager.h"
#import "MTCommentNewsTableViewCell.h"
#import "MTNewsCommentItem.h"
#import "MTNewsItem.h"
#import "MTApiHelper.h"
#import "MTBaseViewController+Alerts.h"
#import "SVProgressHUD.h"

@interface MTCurrentNewsViewController () <UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate, MTDetailsNewsTableViewCellDelegate>
{
    IBOutlet UITableView *detailsNewsTableView;
    
    IBOutlet UITextField *commentTextField;
    IBOutlet UIButton *sendBtn;
    IBOutlet UIView *containerTextField;
    
    IBOutlet UILabel *addressLabel;
    IBOutlet UILabel *accountLabel;
    
    float detailsNewsCellHeight;
    
    MTNewsItem *currentNews;
    
    NSMutableArray <MTNewsCommentItem *> *newsCommentArray;
}

@end

@implementation MTCurrentNewsViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    containerTextField.layer.cornerRadius = 4.f;
    
    [self setupNavBar];
    [self setupDetailsNewsCellHeight];
    [self setupAccountItems];

    //newsCommentArray = [[NSMutableArray alloc] initWithObjects:news, nil];
    
    detailsNewsTableView.rowHeight = UITableViewAutomaticDimension;
    detailsNewsTableView.estimatedRowHeight = 72;
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self
                                                                          action:@selector(hideKeyboard)];
    [detailsNewsTableView addGestureRecognizer:tap];
    
    [self newsRequest];
    
    [self tempHiddenUIElements];
}

- (void)tempHiddenUIElements
{
    containerTextField.hidden = YES;
    sendBtn.hidden = YES;
}

- (void)setupNavBar
{
    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    
    self.navigationItem.title = NSLocalizedString(@"News", nil);
    
    UIBarButtonItem *back = [UIBarButtonItem new];
    back.title = NSLocalizedString(@"Back", nil);
    self.navigationController.navigationBar.topItem.backBarButtonItem = back;
}

- (void)setupAccountItems
{
    addressLabel.text = [CLIENT_DATA_MANAGER getUserAddress];
    accountLabel.text = [CLIENT_DATA_MANAGER getPersonalAccountNumber];
}

- (void)setupDetailsNewsCellHeight
{
    if (IS_IPHONE_4_OR_LESS || IS_IPHONE_5)
        detailsNewsCellHeight = 612.0;
    else if (IS_IPHONE_6)
        detailsNewsCellHeight = 484.0;
    else if (IS_IPHONE_6P)
        detailsNewsCellHeight = 532.0;
    else
        detailsNewsCellHeight = 412.0;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark -

- (void)setNewsItem:(MTNewsItem *)item
{
    currentNews = item;
}

#pragma mark - News Request

- (void)newsRequest
{
    __weak __typeof(self)weakSelf = self;
    
    [SVProgressHUD show];
    
    [API_HELPER addOperationWithType:MTApiOpNewsDetails
                              params:@{ @"ID" : currentNews.newsId }
                             connect:^(BOOL state) {
                                 
                                 if (!state)
                                 {
                                     [SVProgressHUD dismiss];
                                     [weakSelf showConnectionProblemAlert];
                                 }
                                 
                             } completion:^(BOOL status, id data, NSString *reason) {
                                 
                                 if (status)
                                     [weakSelf processServerData:(NSDictionary *)data];
                                 else
                                 {
                                     [SVProgressHUD dismiss];
                                     
                                     [weakSelf showAlertWithTitle:NSLocalizedString(@"Error", nil)
                                                          message:reason];
                                 }
                             }];
}

- (void)processServerData:(NSDictionary *)dict
{
    [SVProgressHUD dismiss];
    
    MTServerResponse *resp = [MTServerResponse parseServerAnswer:dict
                                                          opType:MTApiOpNewsDetails];
    if ([resp isSuccessResponse])
    {
        [currentNews setDetailsFromDict:[resp getResponseData]];

        [detailsNewsTableView reloadData];
    }
    else
        [self showAlertWithTitle:NSLocalizedString(@"Error", nil)
                         message:[resp getReasonMessage]];
}

#pragma mark - Table View

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return newsCommentArray.count + 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0)
        return detailsNewsCellHeight;
    else
        return UITableViewAutomaticDimension;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0)
        return [MTDetailsNewsTableViewCell dequeueForTableView:tableView
                                                     indexPath:indexPath
                                                      delegate:self
                                                          item:currentNews];
    else
        return [MTCommentNewsTableViewCell dequeueForTableView:tableView
                                                     indexPath:indexPath
                                                          item:newsCommentArray[indexPath.row]];
}

- (void)likeButtonClicked:(UIButton *)sender
{
//    sender.selected = sender.isSelected ? NO : YES;
//
//    MTDetailsNewsTableViewCell *cell = [detailsNewsTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
//    cell.likeCountLabel.text = [NSString stringWithFormat:@"%d", [cell.likeCountLabel.text intValue] + (sender.isSelected ? 1 : -1)];
}

#pragma mark - MTDetailsNewsTableViewCellDelegate

- (void)updateCellHeight:(float)height
{
    detailsNewsCellHeight = height;
}

#pragma mark - Text Field

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    
    if(touch.phase == UITouchPhaseBegan)
        [commentTextField resignFirstResponder];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    
    return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    float keyboardValue;
    
    if (IS_IPHONE_6)
        keyboardValue = -152.0;
    else if (IS_IPHONE_6P)
        keyboardValue = -162.0;
    else
        keyboardValue = -115.0;

    [self.view setFrame:CGRectMake(0.0,
                                   keyboardValue,
                                   self.view.frame.size.width,
                                   self.view.frame.size.height)];
    
    return YES;
}

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
    commentTextField.text = @"";
    
    [self.view setFrame:CGRectMake(0,
                                   64.0,
                                   self.view.frame.size.width,
                                   self.view.frame.size.height)];
    
    [self.view endEditing:YES];
    
    return YES;
}

- (void)hideKeyboard
{
    [commentTextField resignFirstResponder];
}

- (IBAction)sendPressed:(id)sender
{
//    if (commentTextField.text && commentTextField.text.length > 0)
//    {
//        NSDate *today = [NSDate date];
//        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
//        [dateFormatter setTimeStyle:NSDateFormatterShortStyle];
//
//        MTNewsCommentItem *comment = [MTNewsCommentItem new];
//        comment.textComment = commentTextField.text;
//        comment.author = @"Иванов Иван Иванович";
//        comment.date = [NSString stringWithFormat:@"сегодня %@",[dateFormatter stringFromDate:today]];
//        comment.showCommentLogo = YES;
//
//        [newsCommentArray addObject:comment];
//
//        [self performSelector:@selector(reloadTableView) withObject:nil afterDelay:0.3f];
//
//        [self.view endEditing:YES];
//    }
}

- (void)reloadTableView
{
//    [detailsNewsTableView reloadData];
//
//    NSIndexPath *ipath = [NSIndexPath indexPathForRow:newsCommentArray.count - 1 inSection:0];
//    [detailsNewsTableView scrollToRowAtIndexPath:ipath atScrollPosition:UITableViewScrollPositionTop animated:YES];
//
//    MTDetailsNewsTableViewCell *cell = [detailsNewsTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
//
//    cell.commentBtn.selected = YES;
//    cell.commentCountLabel.text = [NSString stringWithFormat:@"%d", [cell.commentCountLabel.text intValue] + 1];
}

@end
