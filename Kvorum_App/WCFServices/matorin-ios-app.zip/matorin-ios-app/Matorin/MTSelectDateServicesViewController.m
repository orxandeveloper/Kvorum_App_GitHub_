//
//  MTSelectDateServicesViewController.m
//  Matorin
//
//  Created by Work Inteleks on 9/14/17.
//

#import "MTSelectDateServicesViewController.h"
#import "MTClientDataManager.h"
#import "MTServiceDate.h"

@interface MTSelectDateServicesViewController ()
{
    IBOutlet UIDatePicker *datePicker;
    
    IBOutlet UILabel *addressLabel;
    IBOutlet UILabel *accountLabel;
    
    IBOutlet UIButton *dateBtn;
    IBOutlet UIButton *withTimeBtn;
    IBOutlet UIButton *toTimeBtn;
    
    NSDateFormatter *dateFormatter;
    
    int curretnTag;
    
    NSString *currentServiceDate;
    NSString *withServiceTime;
    NSString *toServiceTime;
    
    BOOL dateIsSelected;
}

@end

@implementation MTSelectDateServicesViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    dateIsSelected = NO;
    
    [self setupNavBar];
    [self setupAccountItems];
    
    dateFormatter = [NSDateFormatter new];
    [dateFormatter setDateStyle:NSDateFormatterMediumStyle];
    [dateFormatter setDateFormat:@"dd MMMM yyyy"];
    
    currentServiceDate = [dateFormatter stringFromDate:datePicker.date];
    withServiceTime = @"11 : 00";
    toServiceTime  = @"12 : 00";
    
    [dateBtn setTitle:[dateFormatter stringFromDate:datePicker.date]
             forState:UIControlStateNormal];
    
    datePicker.hidden = YES;
    [datePicker addTarget:self
                   action:@selector(onDatePickerValueChanged:)
         forControlEvents:UIControlEventValueChanged];
}

- (void)setupAccountItems
{
    addressLabel.text = [CLIENT_DATA_MANAGER getUserAddress];
    accountLabel.text = [CLIENT_DATA_MANAGER getPersonalAccountNumber];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    if (dateIsSelected)
    {
        MTServiceDate *serviceDate = [MTServiceDate new];
        serviceDate.serviceDate     = currentServiceDate;
        serviceDate.withServiceTime = withServiceTime;
        serviceDate.toServiceTime   = toServiceTime;
        [CLIENT_DATA_MANAGER setupOrderedServicesDate:serviceDate];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)setupNavBar
{
    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    
    self.navigationItem.title = NSLocalizedString(@"Время выполнения", nil);
    
    UIBarButtonItem *back= [UIBarButtonItem new];
    back.title = NSLocalizedString(@"Назад", nil);
    self.navigationController.navigationBar.topItem.backBarButtonItem = back;
}

- (IBAction)selectDate:(UIButton *)sender
{
    dateIsSelected = YES;
    
    curretnTag = (int)sender.tag;
    
    [dateFormatter setDateFormat:@"dd MMMM yyyy"];
    
    datePicker.hidden = NO;
    [datePicker setMinimumDate:[NSDate date]];
    [datePicker setDate:[dateFormatter dateFromString:currentServiceDate]];
    [datePicker setDatePickerMode:UIDatePickerModeDate];
}

- (IBAction)selectTime:(UIButton *)sender
{
    dateIsSelected = YES;
    
    curretnTag = (int)sender.tag;
    
    [dateFormatter setDateFormat:@"HH : mm"];
    
    NSDate *time;
    
    if (curretnTag == 1)
        time = [dateFormatter dateFromString:withServiceTime];
    else
        time = [dateFormatter dateFromString:toServiceTime];
    
    datePicker.hidden = NO;
    [datePicker setMinimumDate:nil];
    [datePicker setDate:time];
    [datePicker setDatePickerMode:UIDatePickerModeTime];
    
    [self setupTimeInterval:curretnTag == 2 ? YES : NO];
}

- (void)onDatePickerValueChanged:(UIDatePicker *)datePicker
{
    if (curretnTag == 0)
    {
        [dateBtn setTitle:[dateFormatter stringFromDate:datePicker.date] forState:UIControlStateNormal];
        
        currentServiceDate = [dateFormatter stringFromDate:datePicker.date];
        
        [self setupTimes];
    }
    else if (curretnTag == 1)
    {
        [withTimeBtn setTitle:[dateFormatter stringFromDate:datePicker.date] forState:UIControlStateNormal];
        
        withServiceTime = [dateFormatter stringFromDate:datePicker.date];
        
        [self setupTimeInterval:NO];
    }
    else if (curretnTag == 2)
    {
        [toTimeBtn setTitle:[dateFormatter stringFromDate:datePicker.date] forState:UIControlStateNormal];
        
        toServiceTime = [dateFormatter stringFromDate:datePicker.date];
        
        [self setupTimeInterval:YES];
    }
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    
    if (touch.phase == UITouchPhaseBegan)
        datePicker.hidden = YES;
}

- (void)setupTimeInterval:(BOOL)toDate
{
    NSDateFormatter *df = [NSDateFormatter new];
    [df setDateFormat:@"HH : mm"];
    
    NSDate *curTime = [NSDate date];
    NSString *curTimeString = [df stringFromDate:curTime];
    curTime = [df dateFromString:curTimeString];
    
    NSDate *withTime = [df dateFromString:withServiceTime];
    NSDate *toTime   = [df dateFromString:toServiceTime];
    
    if ([self selectedDateIsCurrentDate] && !toDate && ([curTime compare:withTime] == NSOrderedDescending))
    {
        [datePicker setDate:curTime];
        withTime = curTime;
        withServiceTime = [df stringFromDate:withTime];
        [withTimeBtn setTitle:withServiceTime forState:UIControlStateNormal];
    }
    
    NSTimeInterval secondsInEightHours = 60 * 60;
    NSDate *dateEightHoursAhead = [withTime dateByAddingTimeInterval:secondsInEightHours];

    if (([dateEightHoursAhead compare:toTime] == NSOrderedDescending))
    {
        toServiceTime = [df stringFromDate:dateEightHoursAhead];
        
        [toTimeBtn setTitle:toServiceTime forState:UIControlStateNormal];
        
        if (toDate)
            [datePicker setDate:[df dateFromString:toServiceTime]];
    }
}

- (BOOL)selectedDateIsCurrentDate
{
    NSDateFormatter *df = [NSDateFormatter new];
    [df setDateFormat:@"dd MMMM yyyy"];
    
    NSString *date = [df stringFromDate:[NSDate date]];
    
    return [currentServiceDate isEqualToString:date];;
}

- (void)setupTimes
{
    NSDateFormatter *df = [NSDateFormatter new];
    [df setDateFormat:@"HH : mm"];
    
    NSDate *curTime = [NSDate date];
    NSString *curTimeString = [df stringFromDate:curTime];
    curTime = [df dateFromString:curTimeString];
    
    NSDate *withTime = [df dateFromString:withServiceTime];
    NSDate *toTime   = [df dateFromString:toServiceTime];
    
    if ([self selectedDateIsCurrentDate] && ([curTime compare:withTime] == NSOrderedDescending))
    {
        withTime = curTime;
        withServiceTime = [df stringFromDate:withTime];
        [withTimeBtn setTitle:withServiceTime forState:UIControlStateNormal];
    }
    
    NSTimeInterval secondsInEightHours = 60 * 60;
    NSDate *dateEightHoursAhead = [withTime dateByAddingTimeInterval:secondsInEightHours];
    
    if (([dateEightHoursAhead compare:toTime] == NSOrderedDescending))
    {
        toServiceTime = [df stringFromDate:dateEightHoursAhead];
        [toTimeBtn setTitle:toServiceTime forState:UIControlStateNormal];
    }
}

@end
