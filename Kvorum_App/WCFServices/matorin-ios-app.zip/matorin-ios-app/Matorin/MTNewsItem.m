//
//  MTNewsItem.m
//  Matorin
//
//  Created by Work Inteleks.
//

#import "MTNewsItem.h"
#import "NSDate+Additions.h"

@implementation MTNewsItem

@synthesize newsId;
@synthesize date;
@synthesize name;
@synthesize previewPic;
@synthesize detailPic;
@synthesize previewText;
@synthesize detailText;
@synthesize previewTextType;
@synthesize detailTextType;

+ (NSArray<MTNewsItem *> *)parseNewsFeedFromDict:(NSDictionary *)dict
{
    NSMutableArray *news = [NSMutableArray new];
    
    for (NSDictionary *oneDict in dict[@"NEWS"])
    {
        MTNewsItem *item = [MTNewsItem newsItemFromDict:oneDict];
        [news addObject:item];
    }
    return (NSArray *)news;
}

+ (MTNewsItem *)newsItemFromDict:(NSDictionary *)dict
{
    MTNewsItem *item = [MTNewsItem new];
    
    item.newsId = @([dict[@"ID"] integerValue]);
    item.date = @([dict[@"DATE_CREATE"] integerValue]);
    
    item.name = dict[@"NAME"];
    item.previewPic = dict[@"PREVIEW_PICTURE"];
    item.previewText = dict[@"PREVIEW_TEXT"];
    item.previewTextType = dict[@"PREVIEW_TEXT_TYPE"];
    
    return item;
}

#pragma mark -

- (void)setDetailsFromDict:(NSDictionary *)dict
{
    detailText     = dict[@"DETAIL_TEXT"];
    detailPic      = dict[@"DETAIL_PICTURE"];
    detailTextType = dict[@"DETAIL_TEXT_TYPE"];
}

#pragma mark -

- (NSString *)getNewsDate
{
    return [[NSDate dateWithTimeIntervalSince1970:[date unsignedIntegerValue]] getAsRedableString];
}

#pragma mark - Description

- (NSString *)description
{
    return [NSString stringWithFormat:@"NEWS => %@ : %@",
            newsId,
            name];
}

@end
