//
//  MTService.m
//  Matorin
//
//  Created by Sergej Bogatenko on 11/24/17.
//  Copyright © 2017 Matorin. All rights reserved.
//

#import "MTService.h"

@implementation MTService

@synthesize kGUID;
@synthesize work_kind;
@synthesize visible;

@synthesize showCountBtns; //API not return
@synthesize price;         //API not return

@synthesize count;
@synthesize isCheck;

+ (NSArray <MTService *> *)parseServiceFromDict:(NSDictionary *)dict
                                    onlyVisible:(BOOL)onlyVisible
{
    NSMutableArray *services = [NSMutableArray new];
    
    for (NSDictionary *oneDict in dict[@"SERVICES"])
    {
        MTService *service = [MTService serviceFromDict:oneDict];
        if (onlyVisible)
        {
            if (service.visible)
                [services addObject:service];
        }
        else
            [services addObject:service];
    }
    return (NSArray *)services;
}

+ (MTService *)serviceFromDict:(NSDictionary *)dict
{
    MTService *service = [MTService new];
    
    service.kGUID     = dict[@"kGUID"];
    service.work_kind = dict[@"WORK_KIND"];
    service.visible   = [dict[@"VISIBLE"] boolValue];
    
    service.showCountBtns = YES;
    service.price         = @(1000);
    
    service.count = 1;
    service.isCheck = NO;
    
    return service;
}

#pragma mark - Description

- (NSString *)description
{
    return [NSString stringWithFormat:@"SERVICE => %@ : %@ | COUNT %i",
            work_kind,
            price,
            count];
}

@end
