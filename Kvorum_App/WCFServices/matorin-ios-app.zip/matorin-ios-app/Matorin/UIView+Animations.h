//
//  UIView+Animations.h
//  Matorin
//
//  Created by Work Inteleks on 9/4/17.
//

#import <UIKit/UIKit.h>

@interface UIView (Animations)

- (void)showViewWithAnimationInPoint:(CGPoint)point;
- (void)hideViewWithAnimation;

@end
