//
//  UIViewController+Alerts.h
//  Matorin
//  Created by Oleg Bogatenko.
//

#import "MTBaseViewController.h"

@interface MTBaseViewController (Alerts)

- (void)showAlertWithTitle:(NSString *)title
                   message:(NSString *)message;

- (void)showConnectionProblemAlert;

@end
