//
//  MTLoginViewController.m
//  Matorin
//
//  Created by Work Inteleks on 9/4/17.
//

#import "MTLoginViewController.h"
#import "MTSideViewController.h"
#import "UIViewController+LGSideMenuController.h"
#import "MTClientDataManager.h"
#import "MTApiHelper.h"
#import "MTBaseViewController+Alerts.h"
#import "NSString+Additions.h"
#import "SVProgressHUD.h"

@interface MTLoginViewController () <UITextFieldDelegate>
{
    IBOutlet UITextField *loginField;
    IBOutlet UITextField *passwField;
    
    IBOutlet UILabel *alertLabel;
    
    IBOutlet UIButton *nextBtn;
    
    IBOutlet UIView *offerView;
    IBOutlet UISwitch *offerSwitch;
    
    IBOutlet UIButton *declineOfferBtn;
    IBOutlet UIButton *acceptOfferBtn;
}

- (IBAction)loginNow:(id)sender;
- (IBAction)changeOfferState:(UISwitch *)sender;
- (IBAction)acceptOffer:(id)sender;
- (IBAction)declineOffer:(id)sender;
- (IBAction)callToSupport:(id)sender;

@end

@implementation MTLoginViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    declineOfferBtn.layer.cornerRadius = 12.5f;
    acceptOfferBtn.layer.cornerRadius = 12.5f;
    
    self.navigationItem.title = NSLocalizedString(@"Login to your account", nil);
    
    nextBtn.layer.borderWidth = 2.f;
    nextBtn.layer.borderColor = [UIColor colorWithRed:239.f/255.f
                                                green:239.f/255.f
                                                 blue:244.f/255.f
                                                alpha:1.f].CGColor;
    nextBtn.layer.cornerRadius = 12.5f;
    
    offerView.hidden = YES;
    alertLabel.hidden = YES;
}

- (void)showErrorAlertLabelWithMessage:(NSString *)msg
{
    alertLabel.text   = msg;
    alertLabel.hidden = NO;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - Actions

- (IBAction)changeOfferState:(UISwitch *)sender
{
    acceptOfferBtn.enabled = sender.isOn;
}

- (IBAction)loginNow:(id)sender
{
    if ([loginField.text isNotEmpty] &&
        [passwField.text isNotEmpty])
    {
       [self userLoginRequest];
    }
    else
        alertLabel.hidden = NO;
}

- (IBAction)acceptOffer:(id)sender
{
    [CLIENT_DATA_MANAGER setOfferAsViewed];
    
    [self goToNews];
}

- (IBAction)declineOffer:(id)sender
{
    offerView.hidden = YES;
}

- (IBAction)callToSupport:(id)sender
{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"tel://+74955444000"]];
}

#pragma mark -

- (void)goToNews
{
    MTSideViewController *mainViewController = (MTSideViewController *)self.sideMenuController;
    
    UINavigationController *navigationController = (UINavigationController *)mainViewController.rootViewController;
    UIViewController *viewController = [self.storyboard instantiateViewControllerWithIdentifier:@"MTNewsViewController"];
    
    [navigationController setViewControllers:@[viewController]];
    
    [mainViewController hideLeftViewAnimated:YES
                                       delay:0
                           completionHandler:nil];
}

#pragma mark - UITextField

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    
    return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    alertLabel.hidden = YES;
    
    return YES;
}

#pragma mark -

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
   [self.view endEditing:YES];
}

#pragma mark - Auth User Request

- (void)userLoginRequest
{
    __weak __typeof(self)weakSelf = self;
    
    [SVProgressHUD show];

    [API_HELPER addOperationWithType:MTApiOpAuth
                              params:@{ @"log" : loginField.text,
                                        @"pass" : passwField.text }
                             connect:^(BOOL state) {
                                 
                                 if (!state)
                                 {
                                     [SVProgressHUD dismiss];
                                     [weakSelf showConnectionProblemAlert];
                                 }
                                 
                             } completion:^(BOOL status, id data, NSString *reason) {
                                 
                                 if (status)
                                     [weakSelf processUserOutputServerData:(NSDictionary *)data];
                                 else
                                 {
                                     [SVProgressHUD dismiss];
                                     
                                     [weakSelf showErrorAlertLabelWithMessage:reason];
                                 }
                             }];
}

- (void)processUserOutputServerData:(NSDictionary *)dict
{
    MTServerResponse *resp = [MTServerResponse parseServerAnswer:dict
                                                          opType:MTApiOpAuth];
    
    if ([resp isSuccessResponse])
    {
        [CLIENT_DATA_MANAGER setUserAccountNumber:@([loginField.text intValue])
                               infoFromServerDict:[resp getResponseData]];
        
        [self userObjectInfoRequest];
    }
    else
    {
        [SVProgressHUD dismiss];
        
        [self showErrorAlertLabelWithMessage:[resp getReasonMessage]];
    }
}

- (void)userObjectInfoRequest
{
    __weak __typeof(self)weakSelf = self;
    
    [API_HELPER addOperationWithType:MTApiOpObjInfo
                              params:nil
                             connect:^(BOOL state) {
                                 
                                 if (!state)
                                 {
                                     [SVProgressHUD dismiss];
                                     [weakSelf showConnectionProblemAlert];
                                 }
                                 
                             } completion:^(BOOL status, id data, NSString *reason) {

                                 if (status)
                                     [weakSelf nextStepToOfferWithData:(NSDictionary *)data];
                                 else
                                 {
                                     [SVProgressHUD dismiss];
                                     
                                     [weakSelf showErrorAlertLabelWithMessage:reason];
                                 }
                             }];
}

- (void)nextStepToOfferWithData:(NSDictionary *)data
{
    MTServerResponse *resp = [MTServerResponse parseServerAnswer:data
                                                          opType:MTApiOpObjInfo];
    [SVProgressHUD dismiss];
    
    if ([resp isSuccessResponse])
    {
        [CLIENT_DATA_MANAGER setUserObjectInfoFromServerDict:[resp getResponseData]];
        
        if ([CLIENT_DATA_MANAGER isOfferViewed])
            [self goToNews];
        else
            offerView.hidden = NO;
    }
    else
        [self showErrorAlertLabelWithMessage:[resp getReasonMessage]];
}

@end
