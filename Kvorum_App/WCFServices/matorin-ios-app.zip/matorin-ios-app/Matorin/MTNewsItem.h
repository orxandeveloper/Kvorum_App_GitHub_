//
//  MTNewsItem.h
//  Matorin
//
//  Created by Work Inteleks.
//

#import <Foundation/Foundation.h>

@interface MTNewsItem : NSObject

@property (nonatomic) NSNumber *newsId; // "ID"
@property (nonatomic) NSNumber *date;   // "DATE_CREATE"

@property (nonatomic, copy) NSString *name; // "NAME"

@property (nonatomic, copy) NSString *previewPic;  // "PREVIEW_PICTURE"
@property (nonatomic, copy) NSString *previewText; // "PREVIEW_TEXT"

@property (nonatomic, copy) NSString *detailText; // "DETAIL_TEXT"
@property (nonatomic, copy) NSString *detailPic;  // "DETAIL_PICTURE"

@property (nonatomic, copy) NSString *previewTextType; // "PREVIEW_TEXT_TYPE"
@property (nonatomic, copy) NSString *detailTextType; // "DETAIL_TEXT_TYPE"

+ (NSArray <MTNewsItem *> *)parseNewsFeedFromDict:(NSDictionary *)dict;

- (NSString *)getNewsDate;

- (void)setDetailsFromDict:(NSDictionary *)dict;

@end
