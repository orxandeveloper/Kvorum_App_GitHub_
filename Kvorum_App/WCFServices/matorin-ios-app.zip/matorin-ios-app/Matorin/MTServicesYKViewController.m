//
//  MTServicesYKViewController.m
//  Matorin
//
//  Created by Work Inteleks on 9/6/17.
//

#import "MTServicesYKViewController.h"

@interface MTServicesYKViewController ()

@end

@implementation MTServicesYKViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self setupNavBar];
}

- (void)setupNavBar
{
    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    
    self.navigationItem.title = NSLocalizedString(@"Услуги УК", nil);
    
    UIBarButtonItem *back= [UIBarButtonItem new];
    back.title = NSLocalizedString(@"Назад", nil);
    self.navigationController.navigationBar.topItem.backBarButtonItem = back;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (IBAction)selectCategory:(UIButton *)sender
{
    if (sender.tag == 0)
    {
        NSLog(@"button 0");
            
        MTServicesYKViewController *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"MTRealizationServicesViewController"];
        
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if (sender.tag == 1)
    {
        NSLog(@"button 1");
    }
    else if (sender.tag == 2)
    {
        NSLog(@"button 2");
    }
    else if (sender.tag == 3)
    {
        NSLog(@"button 3");
    }
    else if (sender.tag == 4)
    {
        NSLog(@"button 4");
    }
    else if (sender.tag == 5)
    {
        NSLog(@"button 5");
    }
}

@end
