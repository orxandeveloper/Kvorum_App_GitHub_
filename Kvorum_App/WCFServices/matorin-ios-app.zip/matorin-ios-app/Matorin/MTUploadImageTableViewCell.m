//
//  MTUploadImageTableViewCell.m
//  Matorin
//
//  Created by Sergej Bogatenko on 12/22/17.
//  Copyright © 2017 Matorin. All rights reserved.
//

#import "MTUploadImageTableViewCell.h"

#import <SDWebImage/UIImageView+WebCache.h>
#import <SDWebImage/UIView+WebCache.h>
#import <SDWebImage/UIButton+WebCache.h>

@interface MTUploadImageTableViewCell()
{
    IBOutlet UIImageView *uploadImage;
}

@end

@implementation MTUploadImageTableViewCell

- (void)awakeFromNib
{
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

- (void)configureWithImage:(NSString *)image
{
    [uploadImage sd_setImageWithURL:[NSURL URLWithString:image]];
}

#pragma mark -

+ (NSString *)getCellIdentifier
{
    return @"UploadCell";
}

+ (MTUploadImageTableViewCell *)dequeueForTableView:(UITableView *)tableView
                                          indexPath:(NSIndexPath *)indexPath
                                           imageUrl:(NSString *)imageUrl
{
    MTUploadImageTableViewCell *cell = (MTUploadImageTableViewCell *)[tableView dequeueReusableCellWithIdentifier:[MTUploadImageTableViewCell getCellIdentifier]];
    
    if (!cell)
        cell = [[MTUploadImageTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                                 reuseIdentifier:[MTUploadImageTableViewCell getCellIdentifier]];
    
    [cell configureWithImage:imageUrl];
    
    return cell;
}

@end
