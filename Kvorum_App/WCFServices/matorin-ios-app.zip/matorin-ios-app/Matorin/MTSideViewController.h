//
//  MTSideViewController.h
//  Matorin
//
//  Created by Work Inteleks on 8/31/17.
//

#import "LGSideMenuController.h"

@interface MTSideViewController : LGSideMenuController

@end
