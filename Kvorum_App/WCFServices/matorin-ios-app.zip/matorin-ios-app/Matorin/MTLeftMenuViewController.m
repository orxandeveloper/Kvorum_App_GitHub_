//
//  MTLeftMenuViewController.m
//  Matorin
//
//  Created by Work Inteleks on 8/31/17.
//

#import "MTLeftMenuViewController.h"
#import "MTSideViewController.h"
#import "UIViewController+LGSideMenuController.h"
#import "MTMenuTableViewCell.h"
#import "MTMenuItem.h"
#import "MTClientDataManager.h"

@interface MTLeftMenuViewController () <UITableViewDelegate, UITableViewDataSource>
{
    IBOutlet UIImageView *avatarImage;
    IBOutlet UIButton *toProfileBtn;
    
    IBOutlet UILabel *userName;
    
    IBOutlet UITableView *menuTableView;
    
    NSArray <MTMenuItem *> *menuItems;
}

- (IBAction)openUserProfile:(id)sender;

@end

@implementation MTLeftMenuViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self setupMenuItems];
    [self setupSideMenuViews];
    
    [self addUserAuthListener];
    
    menuTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    
    avatarImage.layer.cornerRadius = avatarImage.frame.size.width / 2.f;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)addUserAuthListener
{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(userAuthStateChanged)
                                                 name:MTAuthNotification
                                               object:nil];
}

- (void)userAuthStateChanged
{
    [self setupSideMenuViews];
}

- (void)setupSideMenuViews
{
    if ([CLIENT_DATA_MANAGER isAuthorized])
        userName.text = [CLIENT_DATA_MANAGER getUserFullName];
}

- (void)setupMenuItems
{
    MTMenuItem *item1 = [MTMenuItem new];
    item1.title = NSLocalizedString(@"Notifications", nil);
    item1.iconName = @"menu_icon_1";
    //item1.actionName = @"";
    item1.showCountLabel = YES;
    item1.countText = @"99+";
    
    MTMenuItem *item2 = [MTMenuItem new];
    item2.title = NSLocalizedString(@"Change account", nil);
    item2.iconName = @"menu_icon_2";
    //item2.actionName = @"";
    
    MTMenuItem *item3 = [MTMenuItem new];
    item3.title = NSLocalizedString(@"News", nil);
    item3.iconName = @"menu_icon_3";
    item3.actionName = @"MTNewsViewController";
    
    MTMenuItem *item4 = [MTMenuItem new];
    item4.title = NSLocalizedString(@"Order service", nil);
    item4.iconName = @"menu_icon_4";
    item4.actionName = @"MTOrderServicesViewController";
    
    MTMenuItem *item5 = [MTMenuItem new];
    item5.title = NSLocalizedString(@"Enter meter values", nil);
    item5.iconName = @"menu_icon_5";
    //item5.actionName = @"";
    
    MTMenuItem *item6 = [MTMenuItem new];
    item6.title = NSLocalizedString(@"Pay now", nil);
    item6.iconName = @"menu_icon_6";
    //item6.actionName = @"";
    
    MTMenuItem *item7 = [MTMenuItem new];
    item7.title = NSLocalizedString(@"My orders", nil);
    item7.iconName = @"menu_icon_7";
    //item7.actionName = @"";
    
    MTMenuItem *item8 = [MTMenuItem new];
    item8.title = NSLocalizedString(@"FAQ", nil);
    item8.iconName = @"menu_icon_8";
    //item8.actionName = @"";
    
    MTMenuItem *item9 = [MTMenuItem new];
    item9.title = NSLocalizedString(@"Page of my home", nil);
    item9.iconName = @"menu_icon_9";
    //item9.actionName = @"MTProfileViewController";
    
//    Temp comment
//    menuItems = @[item1, item2, item3, item4, item5, item6, item7, item8, item9];
    
    menuItems = @[item3, item4];
}

#pragma mark - Actions

- (void)openUserProfile:(id)sender
{
    UIViewController *viewController = [self.storyboard instantiateViewControllerWithIdentifier:@"MTProfileViewController"];
    
    [[self getRootNavigationCtrl] pushViewController:viewController
                                            animated:NO];
    
    [(MTSideViewController *)self.sideMenuController hideLeftViewAnimated:YES
                                                                    delay:0
                                                        completionHandler:nil];
}

#pragma mark -

- (UINavigationController *)getRootNavigationCtrl
{
    MTSideViewController *mainViewController = (MTSideViewController *)self.sideMenuController;
    
    return (UINavigationController *)mainViewController.rootViewController;
}

#pragma mark - Table View

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return menuItems.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return [MTMenuTableViewCell dequeueForTableView:tableView
                                          indexPath:indexPath
                                               item:menuItems[indexPath.row]];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(nonnull NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    
    if (menuItems[indexPath.row].actionName)
    {
        UIViewController *viewController = [self.storyboard instantiateViewControllerWithIdentifier:menuItems[indexPath.row].actionName];
        
        [[self getRootNavigationCtrl] setViewControllers:@[viewController]];
        
        [(MTSideViewController *)self.sideMenuController hideLeftViewAnimated:YES
                                                                        delay:0
                                                            completionHandler:nil];
    }
}

@end
