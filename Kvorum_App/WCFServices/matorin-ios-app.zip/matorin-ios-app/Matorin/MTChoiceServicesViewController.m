//
//  MTChoiceServicesViewController.m
//  Matorin
//
//  Created by Work Inteleks on 9/13/17.
//

#import "MTChoiceServicesViewController.h"
#import "MTServiceYKCell.h"
#import "MTotalServiceCell.h"
#import "MTClientDataManager.h"
#import "MTApiHelper.h"
#import "MTBaseViewController+Alerts.h"
#import "SVProgressHUD.h"
#import "MTService.h"

@interface MTChoiceServicesViewController () <UITableViewDelegate, UITableViewDataSource, MTServiceYKTableViewCellDelegate>
{
    IBOutlet UITableView *serviceTableView;

    NSArray <MTService *> *servicesArray;
    
    NSNumber *totalPrice;
}

@end

@implementation MTChoiceServicesViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    totalPrice = @(0);
    
    [self setupMenuBarButtons];
    [self servicesRequest];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)setupMenuBarButtons
{
    self.navigationItem.title = NSLocalizedString(@"Выбрать услугу", nil);
    
    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    
    UIBarButtonItem *cancel = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Отменить", nil)
                                                              style:UIBarButtonItemStyleDone
                                                             target:self
                                                             action:@selector(cancelAction)];
    
    self.navigationItem.leftBarButtonItem = cancel;
    
    UIBarButtonItem *confirm = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Готово", nil)
                                                                style:UIBarButtonItemStyleDone
                                                               target:self
                                                               action:@selector(confirmAction)];
    
    self.navigationItem.rightBarButtonItem = confirm;
    
    self.navigationItem.hidesBackButton = YES;
}

- (void)cancelAction
{
    [CLIENT_DATA_MANAGER clearOrderedServices];
    
    [self back];
}

- (void)confirmAction
{
    [self back];
}

- (void)back
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Services Request

- (void)servicesRequest
{
    __weak __typeof(self)weakSelf = self;
    
    [SVProgressHUD show];
    
    [API_HELPER addOperationWithType:MTApiOpGetServices
                              params:nil
                             connect:^(BOOL state) {
                                 
                                 if (!state)
                                 {
                                     [SVProgressHUD dismiss];
                                     [weakSelf showConnectionProblemAlert];
                                 }
                                 
                             } completion:^(BOOL status, id data, NSString *reason) {
                                 
                                 if (status)
                                     [weakSelf processServerData:(NSDictionary *)data];
                                 else
                                 {
                                     [SVProgressHUD dismiss];
                                     
                                     [weakSelf showAlertWithTitle:NSLocalizedString(@"Error", nil)
                                                          message:reason];
                                 }
                             }];
}

- (void)processServerData:(NSDictionary *)dict
{
    [SVProgressHUD dismiss];
    
    MTServerResponse *resp = [MTServerResponse parseServerAnswer:dict
                                                          opType:MTApiOpGetServices];
    if ([resp isSuccessResponse])
    {
        servicesArray = [MTService parseServiceFromDict:[resp getResponseData] onlyVisible:YES];
        
        if (servicesArray.count)
            [serviceTableView reloadData];
    }
    else
        [self showAlertWithTitle:NSLocalizedString(@"Error", nil)
                         message:[resp getReasonMessage]];
}

#pragma mark - Table View

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return servicesArray.count; // + 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == servicesArray.count)
    {
        if (IS_IPHONE_4_OR_LESS || IS_IPHONE_5)
            return 56.0;
        else if (IS_IPHONE_6)
            return 66.0;
        else if (IS_IPHONE_6P)
            return 72.0;
        
        return 56.0;
    }
    else
    {
        if (IS_IPHONE_4_OR_LESS || IS_IPHONE_5)
            return 38.0;
        else if (IS_IPHONE_6)
            return 44.0;
        else if (IS_IPHONE_6P)
            return 49.0;
        
        return 38.0;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
//    if (indexPath.row == servicesArray.count)
//    {
//        return [MTotalServiceCell dequeueForTableView:tableView
//                                            indexPath:indexPath
//                                                price:[totalPrice stringValue]];
//    }
//    else
    {
        return [MTServiceYKCell dequeueForTableView:tableView
                                          indexPath:indexPath
                                           delegate:self
                                            service:servicesArray[indexPath.row]];
    }
}

#pragma mark - MTServiceYKTableViewCellDelegate

- (void)checkServiceYK:(int)index
                   add:(BOOL)add
{
    [self overwriteServicesArray:index increase:NO isCheck:YES add:add];
    
    if (add)
        [CLIENT_DATA_MANAGER addOrderedService:servicesArray[index]];
    else
        [CLIENT_DATA_MANAGER removeOrderedService:servicesArray[index]];
    
    [self addPriceToTotal];
}

- (void)decreaseServiceYK:(int)index
{
//    [CLIENT_DATA_MANAGER removeOrderedService:servicesArray[index]];
//
//    [self overwriteServicesArray:index increase:NO isCheck:NO add:NO];
//
//    if (servicesArray[index].isCheck)
//        [CLIENT_DATA_MANAGER addOrderedService:servicesArray[index]];
//
//    [self addPriceToTotal];
}

- (void)increaseServiceYK:(int)index
{
//    [CLIENT_DATA_MANAGER removeOrderedService:servicesArray[index]];
//
//    [self overwriteServicesArray:index increase:YES isCheck:NO add:NO];
//
//    if (servicesArray[index].isCheck)
//        [CLIENT_DATA_MANAGER addOrderedService:servicesArray[index]];
//
//    [self addPriceToTotal];
}

- (void)overwriteServicesArray:(int)index
                      increase:(BOOL)increase
                       isCheck:(BOOL)isCheck
                           add:(BOOL)add
{
    NSMutableArray *services = [[NSMutableArray alloc] initWithArray:servicesArray];
    
    for (MTService *service in services)
        service.isCheck = NO;

    MTService *service = servicesArray[index];
    if (isCheck)
        service.isCheck = add;
    else
        service.count = service.count + (increase ? +1 : -1);

    [services replaceObjectAtIndex:index withObject:service];

    servicesArray = (NSArray *)services;
}

#pragma mark -

- (void)addPriceToTotal
{
    totalPrice = [CLIENT_DATA_MANAGER getTotalPrice];
    
    [serviceTableView reloadData];
}

@end
