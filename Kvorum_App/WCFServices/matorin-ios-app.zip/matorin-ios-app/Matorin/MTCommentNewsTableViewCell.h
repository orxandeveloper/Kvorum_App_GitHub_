//
//  MTCommentNewsTableViewCell.h
//  Matorin
//
//  Created by Work Inteleks on 9/12/17.
//

#import <UIKit/UIKit.h>

@class MTNewsCommentItem;

@interface MTCommentNewsTableViewCell : UITableViewCell

+ (MTCommentNewsTableViewCell *)dequeueForTableView:(UITableView *)tableView
                                          indexPath:(NSIndexPath *)indexPath
                                               item:(MTNewsCommentItem *)item;
@end
