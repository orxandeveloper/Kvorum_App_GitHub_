//
//  MTNewsCommentItem.m
//  Matorin
//
//  Created by Work Inteleks on 9/13/17.
//

#import "MTNewsCommentItem.h"

@implementation MTNewsCommentItem

@synthesize author;
@synthesize textComment;
@synthesize date;
@synthesize showCommentLogo;

@end
