//
//  MTMenuItem.m
//  Matorin
//
//  Created by Work Inteleks on 8/31/17.
//

#import "MTMenuItem.h"

@implementation MTMenuItem

@synthesize title;
@synthesize iconName;
@synthesize actionName;
@synthesize countText;
@synthesize showCountLabel;

@end
