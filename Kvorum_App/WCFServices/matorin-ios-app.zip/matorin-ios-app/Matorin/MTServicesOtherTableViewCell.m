//
//  MTServicesOtherTableViewCell.m
//  Matorin
//
//  Created by Work Inteleks on 9/7/17.
//

#import "MTServicesOtherTableViewCell.h"

@implementation MTServicesOtherTableViewCell

@synthesize iconImageView;
@synthesize nameServicesLabel;
@synthesize addressServicesLabel;
@synthesize telServicesLabel;

- (void)drawRect:(CGRect)rect
{
    iconImageView.layer.cornerRadius = 8.0;
}

- (void)awakeFromNib
{
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

@end
