//
//  MTBaseViewController.h
//  Created by Oleg Bogatenko.
//

#import <UIKit/UIKit.h>

@interface MTBaseViewController : UIViewController

@end
