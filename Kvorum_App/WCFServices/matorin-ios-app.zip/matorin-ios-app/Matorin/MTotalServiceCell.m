//
//  MTotalServiceCell.m
//  Matorin
//
//  Created by Work Inteleks on 9/18/17.
//

#import "MTotalServiceCell.h"

@interface MTotalServiceCell()
{
    IBOutlet UILabel *totalPriceLabel;
}

@end

@implementation MTotalServiceCell

- (void)awakeFromNib
{
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

- (void)configureWithPrice:(NSString *)price
{
    totalPriceLabel.text = price;
}

#pragma mark -

+ (NSString *)getCellIdentifier
{
    return @"TotalServiceCell";
}

+ (MTotalServiceCell *)dequeueForTableView:(UITableView *)tableView
                                 indexPath:(NSIndexPath *)indexPath
                                     price:(NSString *)price
{
    MTotalServiceCell *cell = (MTotalServiceCell *)[tableView dequeueReusableCellWithIdentifier:[MTotalServiceCell getCellIdentifier]];
    
    if (!cell)
        cell = [[MTotalServiceCell alloc] initWithStyle:UITableViewCellStyleDefault
                                        reuseIdentifier:[MTotalServiceCell getCellIdentifier]];
    [cell configureWithPrice:price];
    
    return cell;
}

@end
