//
//  MTUploadPreviewViewController.m
//  Matorin
//
//  Created by Sergej Bogatenko on 12/22/17.
//  Copyright © 2017 Matorin. All rights reserved.
//

#import "MTUploadPreviewViewController.h"
#import "MTUploadImageTableViewCell.h"
#import "MTClientDataManager.h"

@interface MTUploadPreviewViewController () <UITableViewDelegate, UITableViewDataSource>
{
    IBOutlet UITableView *tableView;
}

- (IBAction)okPressed:(id)sender;

@end

@implementation MTUploadPreviewViewController

@synthesize delegate;

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    tableView.layer.cornerRadius = 5.f;
    self.view.layer.cornerRadius = 5.f;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)okPressed:(id)sender
{
    if (delegate && [delegate respondsToSelector:@selector(dismissPreview)])
        [delegate dismissPreview];
}

#pragma mark - Table View

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [CLIENT_DATA_MANAGER getUploadImages].count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 450.f;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return [MTUploadImageTableViewCell dequeueForTableView:tableView
                                                 indexPath:(NSIndexPath *)indexPath
                                                  imageUrl:[CLIENT_DATA_MANAGER getUploadImages][indexPath.row]];
}

@end
