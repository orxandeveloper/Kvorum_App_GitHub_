//
//  MTServiceItem.m
//  Matorin
//
//  Created by Work Inteleks on 9/6/17.
//

#import "MTServiceItem.h"

@implementation MTServiceItem

@synthesize title;
@synthesize iconName;

@end
