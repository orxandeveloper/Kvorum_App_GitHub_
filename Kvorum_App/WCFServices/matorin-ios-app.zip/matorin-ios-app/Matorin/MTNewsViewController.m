//
//  MTNewsViewController.m
//  Matorin
//
//  Created by Work Inteleks on 8/31/17.
//

#import "MTNewsViewController.h"
#import "UIViewController+LGSideMenuController.h"
#import "MTNewsItem.h"
#import "MTNewsTableViewCell.h"
#import "MTCurrentNewsViewController.h"
#import "MTClientDataManager.h"
#import "MTApiHelper.h"
#import "MTBaseViewController+Alerts.h"
#import "SVProgressHUD.h"

@interface MTNewsViewController () <UITableViewDelegate, UITableViewDataSource>
{
    IBOutlet UITableView *newsTableView;
    
    IBOutlet UILabel *addressLabel;
    IBOutlet UILabel *accountLabel;
    
    NSArray <MTNewsItem *> *newsItems;
}

@end

@implementation MTNewsViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self setupMenuBarButtons];
    
    [self setupAccountItems];
    
    [self newsFeedRequest];
}

- (void)setupAccountItems
{
    addressLabel.text = [CLIENT_DATA_MANAGER getUserAddress];
    accountLabel.text = [CLIENT_DATA_MANAGER getPersonalAccountNumber];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)setupMenuBarButtons
{
    self.navigationItem.title = NSLocalizedString(@"News", nil);
    
    UIButton *barBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    barBtn.bounds = CGRectMake( 0, 0, 22.f, 22.f );
    
    [barBtn addTarget:self
               action:@selector(showLeftViewAnimated:)
     forControlEvents:UIControlEventTouchUpInside];
    
    [barBtn setImage:[UIImage imageNamed:@"nav_burger_btn"] forState:UIControlStateNormal];
    
    UIBarButtonItem *menuBtn = [[UIBarButtonItem alloc] initWithCustomView:barBtn];
    
    self.navigationItem.leftBarButtonItem = menuBtn;
}

#pragma mark - News Request

- (void)newsFeedRequest
{
    __weak __typeof(self)weakSelf = self;
    
    [SVProgressHUD show];
    
    [API_HELPER addOperationWithType:MTApiOpGetNews
                              params:nil
                             connect:^(BOOL state) {
                                 
                                 if (!state)
                                 {
                                     [SVProgressHUD dismiss];
                                     [weakSelf showConnectionProblemAlert];
                                 }
                                 
                             } completion:^(BOOL status, id data, NSString *reason) {
                                 
                                 if (status)
                                     [weakSelf processServerData:(NSDictionary *)data];
                                 else
                                 {
                                     [SVProgressHUD dismiss];
                                     
                                     [weakSelf showAlertWithTitle:NSLocalizedString(@"Error", nil)
                                                          message:reason];
                                 }
                             }];
}

- (void)processServerData:(NSDictionary *)dict
{
    [SVProgressHUD dismiss];
    
    MTServerResponse *resp = [MTServerResponse parseServerAnswer:dict
                                                          opType:MTApiOpGetNews];
    if ([resp isSuccessResponse])
    {
        newsItems = [MTNewsItem parseNewsFeedFromDict:[resp getResponseData]];
        
        if (newsItems.count)
            [newsTableView reloadData];
    }
    else
        [self showAlertWithTitle:NSLocalizedString(@"Error", nil)
                         message:[resp getReasonMessage]];
}

#pragma mark - Table View

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return newsItems.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (IS_IPHONE_4_OR_LESS || IS_IPHONE_5)
        return 210.f;
    else if (IS_IPHONE_6)
        return 246.f;
    else if (IS_IPHONE_6P)
        return 270.f;
    
    return 210.f;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return [MTNewsTableViewCell dequeueForTableView:tableView
                                          indexPath:indexPath
                                               item:newsItems[indexPath.row]];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(nonnull NSIndexPath *)indexPath
{
    MTCurrentNewsViewController *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"MTCurrentNewsViewController"];
    
    [controller setNewsItem:newsItems[indexPath.row]];
    
    [self.navigationController pushViewController:controller
                                         animated:YES];
}

@end
