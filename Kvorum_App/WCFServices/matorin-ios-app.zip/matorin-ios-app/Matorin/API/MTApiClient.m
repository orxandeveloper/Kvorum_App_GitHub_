//
//  MTApiClient.m
//  
//
//  Created by Oleg Bogatenko on 8/22/17.
//

#import "MTApiClient.h"

@implementation MTApiClient

@synthesize delegate;

- (instancetype)init
{
    self = [super initWithBaseURL:[NSURL URLWithString:API_SERVER_URL]];
    
    if (self)
    {
        [self setSerializers];
    }
    return self;
}

- (void)setSerializers
{
    self.requestSerializer  = [AFJSONRequestSerializer serializer];
    self.responseSerializer = [AFJSONResponseSerializer serializer];
}

#pragma mark - ReachabilityManager

- (void)startReachabilityManager
{
    [[AFNetworkReachabilityManager sharedManager] setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        
        if (delegate && [delegate respondsToSelector:@selector(changedNetworkState:)])
        {
            [delegate changedNetworkState:(status == AFNetworkReachabilityStatusReachableViaWWAN
                                           || status == AFNetworkReachabilityStatusReachableViaWiFi)];
        }
    }];
    
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];
}

#pragma mark - Authorization

- (void)userAuthorizationForParams:(NSDictionary *)params
                    withCompletion:(void (^)(BOOL status, id data, NSString *reason))completion
{
    [self POST:@"/WCFServices/MATORIN.QUICK_API.svc/Auth"
    parameters:params
      progress:nil
       success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
           if (completion)
               completion(YES, responseObject, nil);
       } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
           if (completion)
               completion(NO, nil, error.localizedDescription);
       }];
}

#pragma mark - Object Info

- (void)getUserObjectInfoForParams:(NSDictionary *)params
                    withCompletion:(void (^)(BOOL status, id data, NSString *reason))completion
{
    [self POST:@"/WCFServices/MATORIN.QUICK_API.svc/Get_object"
    parameters:params
      progress:nil
       success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
           if (completion)
               completion(YES, responseObject, nil);
       } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
           if (completion)
               completion(NO, nil, error.localizedDescription);
       }];
}

#pragma mark - News Feed

- (void)getNewsFeedForParams:(NSDictionary *)params
              withCompletion:(void (^)(BOOL, id, NSString *))completion
{
    [self POST:@"/WCFServices/MATORIN.QUICK_API.svc/Get_news_feed"
    parameters:params
      progress:nil
       success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
           if (completion)
               completion(YES, responseObject, nil);
       } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
           if (completion)
               completion(NO, nil, error.localizedDescription);
       }];
}

#pragma mark - News Details

- (void)getNewsDetailsForParams:(NSDictionary *)params
                 withCompletion:(void (^)(BOOL status, id data, NSString *reason))completion
{
    [self POST:@"/WCFServices/MATORIN.QUICK_API.svc/Show_news"
    parameters:params
      progress:nil
       success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
           if (completion)
               completion(YES, responseObject, nil);
       } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
           if (completion)
               completion(NO, nil, error.localizedDescription);
       }];
}

#pragma mark - News Comments

- (void)getNewsCommentsForParams:(NSDictionary *)params
                  withCompletion:(void (^)(BOOL status, id data, NSString *reason))completion
{
    [self POST:@"/WCFServices/MATORIN.QUICK_API.svc/Get_news_comment_list"
    parameters:params
      progress:nil
       success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
           if (completion)
               completion(YES, responseObject, nil);
       } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
           if (completion)
               completion(NO, nil, error.localizedDescription);
       }];
}

#pragma mark - Services

- (void)getServicesForParams:(NSDictionary *)params
              withCompletion:(void (^)(BOOL status, id data, NSString *reason))completion
{
    [self POST:@"/WCFServices/MATORIN.QUICK_API.svc/Get_service_list"
    parameters:params
      progress:nil
       success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
           if (completion)
               completion(YES, responseObject, nil);
       } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
           if (completion)
               completion(NO, nil, error.localizedDescription);
       }];
}

- (void)addNewServiceRequestForParams:(NSDictionary *)params
                       withCompletion:(void (^)(BOOL status, id data, NSString *reason))completion
{
    [self POST:@"/WCFServices/MATORIN.QUICK_API.svc/New_request_add"
    parameters:params
      progress:nil
       success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
           if (completion)
               completion(YES, responseObject, nil);
       } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
           if (completion)
               completion(NO, nil, error.localizedDescription);
       }];
}

- (void)uploadFileForParams:(NSDictionary *)params
             withCompletion:(void (^)(BOOL status, id data, NSString *reason))completion
{
    NSData *imageData = UIImageJPEGRepresentation(params[@"file"], 0.9f);
    
    [self POST:@"/WCFServices/MATORIN.QUICK_API.svc/UploadFile"
    parameters:params constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        
        [formData appendPartWithFileData:imageData
                                    name:@"file"
                                fileName:@"file.jpeg"
                                mimeType:@"image/jpeg"];
    } progress:nil
       success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
           if (completion)
               completion(YES, responseObject, nil);
       } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
           if (completion)
               completion(NO, nil, error.localizedDescription);
       }];
}

@end
