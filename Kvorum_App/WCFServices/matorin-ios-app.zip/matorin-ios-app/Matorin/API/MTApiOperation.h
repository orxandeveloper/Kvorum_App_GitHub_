//
//  MTApiOperation.h
//  Created by Oleg Bogatenko.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM (NSInteger, MTApiOpType) {
    MTApiOpAuth,        // /WCFServices/MATORIN.QUICK_API.svc/Auth
    MTApiOpObjInfo,     // /WCFServices/MATORIN.QUICK_API.svc/Get_object
    MTApiOpGetNews,     // /WCFServices/MATORIN.QUICK_API.svc/Get_news_feed
    MTApiOpNewsDetails, // /WCFServices/MATORIN.QUICK_API.svc/Show_news
    MTApiOpGetNComments,// /WCFServices/MATORIN.QUICK_API.svc/Get_news_comment_list
    MTApiOpGetServices, // /WCFServices/MATORIN.QUICK_API.svc/Get_service_list
    MTApiOpAddNewServiceRequest, // /WCFServices/MATORIN.QUICK_API.svc/New_request_add
    MTApiOpUploadFile // /WCFServices/MATORIN.QUICK_API.svc/UploadFile
};

@class MTApiClient;

@interface MTApiOperation : NSOperation

- (instancetype)initWithType:(MTApiOpType)type
                      client:(MTApiClient *)client
                      params:(NSDictionary *)params
                  completion:(void (^)(BOOL, id, NSString *))block;

- (void)runOperation;

@end
