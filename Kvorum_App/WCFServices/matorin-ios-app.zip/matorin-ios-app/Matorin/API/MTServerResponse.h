//
//  MTServerResponse.h
//  Matorin
//
//  Created by Oleg Bogatenko on 11/22/17.
//  Copyright © 2017 Matorin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MTApiOperation.h"

@interface MTServerResponse : NSObject

+ (MTServerResponse *)parseServerAnswer:(NSDictionary *)resp
                                 opType:(MTApiOpType)type;

- (BOOL)isSuccessResponse;
- (NSString *)getReasonMessage;
- (NSDictionary *)getResponseData;

@end
