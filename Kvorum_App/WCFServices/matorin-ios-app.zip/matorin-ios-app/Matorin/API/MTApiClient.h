//
//  MTApiClient.h
//  
//
//  Created by Oleg Bogatenko on 8/22/17.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"

@protocol MTApiClientDelegate <NSObject>

@optional
- (void)changedNetworkState:(BOOL)state;
@end

@interface MTApiClient : AFHTTPSessionManager

@property (nonatomic, weak) id <MTApiClientDelegate> delegate;

- (void)startReachabilityManager;

- (void)userAuthorizationForParams:(NSDictionary *)params
                    withCompletion:(void (^)(BOOL status, id data, NSString *reason))completion;

- (void)getUserObjectInfoForParams:(NSDictionary *)params
                    withCompletion:(void (^)(BOOL status, id data, NSString *reason))completion;

- (void)getNewsFeedForParams:(NSDictionary *)params
              withCompletion:(void (^)(BOOL status, id data, NSString *reason))completion;

- (void)getNewsDetailsForParams:(NSDictionary *)params
                 withCompletion:(void (^)(BOOL status, id data, NSString *reason))completion;

- (void)getNewsCommentsForParams:(NSDictionary *)params
                  withCompletion:(void (^)(BOOL status, id data, NSString *reason))completion;

- (void)getServicesForParams:(NSDictionary *)params
              withCompletion:(void (^)(BOOL status, id data, NSString *reason))completion;

- (void)addNewServiceRequestForParams:(NSDictionary *)params
                       withCompletion:(void (^)(BOOL status, id data, NSString *reason))completion;

- (void)uploadFileForParams:(NSDictionary *)params
             withCompletion:(void (^)(BOOL status, id data, NSString *reason))completion;

@end
