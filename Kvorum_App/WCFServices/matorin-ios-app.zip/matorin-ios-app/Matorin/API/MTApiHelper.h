//
//  MTApiHelper.m
//  Created by Oleg Bogatenko.
//

#import <Foundation/Foundation.h>
#import "MTServerResponse.h"

#define API_HELPER [MTApiHelper sharedManager]

@interface MTApiHelper : NSObject

+ (instancetype)sharedManager;

- (void)load;

- (void)addOperationWithType:(MTApiOpType)type
                      params:(NSDictionary *)params
                     connect:(void (^)(BOOL))conn
                  completion:(void (^)(BOOL, id, NSString *))block;

- (void)resumeWithConnectState:(void (^)(BOOL))conn;

- (void)clearCookies;

@end
