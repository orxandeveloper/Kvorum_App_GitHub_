//
//  MTApiHelper.m
//  Created by Oleg Bogatenko.
//

#import "MTApiHelper.h"
#import "MTApiClient.h"
#import "MTClientDataManager.h"

@interface MTApiHelper () <MTApiClientDelegate>
{
    NSOperationQueue *requestsQueue;
    
    MTApiClient *apiClient;
    
    BOOL isNetworkReachable;
    
    // Because wee need to know network state for first time
    BOOL wasFirstDetection;
    void (^_networkState)(BOOL);
}

@end

@implementation MTApiHelper

+ (instancetype)sharedManager
{
    static dispatch_once_t onceToken = 0;
    static id _sharedManager = nil;
    
    dispatch_once(&onceToken, ^{
        _sharedManager = [self new];
    });
    
    return _sharedManager;
}

- (instancetype)init
{
    self = [super init];
    
    if (self)
    {
        wasFirstDetection = NO;
        
        requestsQueue = [NSOperationQueue new];
        
        apiClient = [MTApiClient new];
        apiClient.delegate = self;
    }
    return self;
}

- (void)addOperationWithType:(MTApiOpType)type
                      params:(NSDictionary *)params
                     connect:(void (^)(BOOL))conn
                  completion:(void (^)(BOOL, id, NSString *))block
{
    NSDictionary *opParams = [self appendAuthAppParams:params
                                              withType:type];
    
    MTApiOperation *op = [[MTApiOperation alloc] initWithType:type
                                                       client:apiClient
                                                       params:opParams
                                                   completion:[block copy]];
    if ([self isExistsAPIOperation:op])
        return;
   
    [requestsQueue addOperation:op];
    
    if ([self isNetworkStateDetected])
    {
        if ([self isOnline])
            [op runOperation];
        else
            conn([self isOnline]);
    }
    else
    {
        __weak __typeof(self)weakSelf = self;
        
        [self waitForNetworkState:^(BOOL state) {
            if (state)
                [weakSelf resumeWithConnectState:nil];
            else
                conn([weakSelf isOnline]);
        }];
    }
}

- (void)resumeWithConnectState:(void (^)(BOOL))conn
{
    if ([self isOnline])
    {
        for (id op in requestsQueue.operations)
        {
            if ([op isKindOfClass:[MTApiOperation class]])
                [op runOperation];
        }
    }
    else
    {
        if (conn)
            conn([self isOnline]);
    }
}

/*
 * Check for identical API request operations
 */
- (BOOL)isExistsAPIOperation:(MTApiOperation *)op
{
    return [requestsQueue.operations containsObject:op];
}

#pragma mark - Auth Token

- (NSDictionary *)appendAuthAppParams:(NSDictionary *)params
                             withType:(MTApiOpType)type
{
    switch (type) {
        case MTApiOpObjInfo:
        case MTApiOpGetNews:
        case MTApiOpAddNewServiceRequest:
        case MTApiOpUploadFile:
        {
            NSMutableDictionary *withAuthParams = [NSMutableDictionary new];
            
            if (params)
                [withAuthParams addEntriesFromDictionary:params];
            
            [withAuthParams setObject:[CLIENT_DATA_MANAGER getUserAuthToken]
                               forKey:@"tokenID"];
            
            return (NSDictionary *)withAuthParams;
        }
            break;
        default:
            return params;
            break;
    }
}

#pragma mark - ReachabilityManager

- (void)load
{
    [apiClient startReachabilityManager];
}

- (BOOL)isNetworkStateDetected
{    
    return wasFirstDetection;
}

- (BOOL)isOnline
{
    return isNetworkReachable;
}

- (void)waitForNetworkState:(void (^)(BOOL))block
{
    if (!wasFirstDetection)
        _networkState = [block copy];
}

#pragma mark - MTApiClientDelegate

- (void)changedNetworkState:(BOOL)state
{
    isNetworkReachable = state;
    
    if (!wasFirstDetection)
    {
        if (_networkState)
            _networkState(isNetworkReachable);
        
        wasFirstDetection = YES;
    }
}

#pragma mark - Cookies

- (void)clearCookies
{
    for (NSHTTPCookie *cookie in [[NSHTTPCookieStorage sharedHTTPCookieStorage] cookies])
        [[NSHTTPCookieStorage sharedHTTPCookieStorage] deleteCookie:cookie];
}

@end
