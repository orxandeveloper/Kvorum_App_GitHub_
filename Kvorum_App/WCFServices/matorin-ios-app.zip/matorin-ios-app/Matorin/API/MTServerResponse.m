//
//  MTServerResponse.m
//  Matorin
//
//  Created by Oleg Bogatenko on 11/22/17.
//  Copyright © 2017 Matorin. All rights reserved.
//

#import "MTServerResponse.h"

@interface MTServerResponse ()
{
    BOOL success;
}

@property (nonatomic, copy) NSString *code;    // "ErrNo"
@property (nonatomic, copy) NSString *result;  // "Result"
@property (nonatomic, copy) NSString *message; // "ErrMsg"

@property (nonatomic, strong) NSDictionary *data;

@end

@implementation MTServerResponse

@synthesize code;
@synthesize result;
@synthesize message;
@synthesize data;

+ (MTServerResponse *)parseServerAnswer:(NSDictionary *)resp
                                 opType:(MTApiOpType)type
{
    if (!resp[@"ResultData"])
        return [MTServerResponse sysErrorResponse];
    
    MTServerResponse *response = [MTServerResponse new];
    
    response.code = resp[@"ResultData"][@"ErrNo"];
    response.result = resp[@"ResultData"][@"Result"];
    response.message = resp[@"ResultData"][@"ErrMsg"];

    if ([response.result isEqualToString:@"Success"])
        response->success = YES;
    else
        return response;
    
    switch (type) {
        case MTApiOpAuth:
        {
            response.data = @{ @"TokenId" : resp[@"ResultData"][@"TokenId"],
                               @"Name" : resp[@"ResultData"][@"Name"],
                               @"Phone" : resp[@"ResultData"][@"Phone"] };
        }
            break;
        case MTApiOpObjInfo:
        {
            response.data = @{ @"Flatno" : resp[@"ResultData"][@"Flatno"],
                               @"Object_name" : resp[@"ResultData"][@"Object_name"] };
        }
            break;
        case MTApiOpGetNews:
        {
            response.data = @{ @"NEWS" : resp[@"ResultData"][@"NEWS"] };
        }
            break;
        case MTApiOpNewsDetails:
        {
            response.data = @{ @"DETAIL_PICTURE" : resp[@"ResultData"][@"DETAIL_PICTURE"],
                               @"DETAIL_TEXT" : resp[@"ResultData"][@"DETAIL_TEXT"],
                               @"DETAIL_TEXT_TYPE" : resp[@"ResultData"][@"DETAIL_TEXT_TYPE"],
                               @"SEARCHABLE_CONTENT" : resp[@"ResultData"][@"SEARCHABLE_CONTENT"] };
        }
            break;
        case MTApiOpGetNComments:
        {
            response.data = @{  };
        }
            break;
        case MTApiOpGetServices:
        {
            response.data = @{ @"SERVICES" : resp[@"ResultData"][@"SERVICES"] };
        }
            break;
        case MTApiOpAddNewServiceRequest:
        {
            response.data = @{ @"NUMBER" : resp[@"ResultData"][@"NUMBER"] };
        }
            break;
        case MTApiOpUploadFile:
        {
            response.data = @{ @"URL" : resp[@"URL"] };
        }
            break;
        default:
            break;
    }
    
    return response;
}

+ (MTServerResponse *)sysErrorResponse
{
    MTServerResponse *response = [MTServerResponse new];
    response.message = NSLocalizedString(@"System error", nil);
    return response;
}

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        success = NO;
    }
    return self;
}

#pragma mark -

- (BOOL)isSuccessResponse
{
    return success;
}

- (NSString *)getReasonMessage
{
    return message;
}

- (NSDictionary *)getResponseData
{
    return data;
}

@end
