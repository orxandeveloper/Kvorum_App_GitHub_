//
//  MTApiOperation.m
//  Created by Oleg Bogatenko.
//

#import "MTApiOperation.h"
#import "MTApiClient.h"

@interface MTApiOperation ()
{
    NSString *operationUuid;
    
    MTApiClient *apiClient;
    
    MTApiOpType operationType;
    
    BOOL finished;
    BOOL executing;
    
    NSDictionary *reqParams;
    
    void (^_handler)(BOOL status, id, NSString *reason);
}

@end

@implementation MTApiOperation

- (instancetype)initWithType:(MTApiOpType)type
                      client:(MTApiClient *)client
                      params:(NSDictionary *)params
                  completion:(void (^)(BOOL, id, NSString *))block
{
    self = [super init];
    
    if (self)
    {
        operationUuid = [[NSUUID UUID] UUIDString];
        
        apiClient = client;
        operationType = type;
        reqParams = params;
        
        executing = NO;
        finished  = NO;
        
        _handler = [block copy];
    }
    return self;
}

#pragma mark -

- (BOOL)isEqual:(MTApiOperation *)operation
{
    return (operationType == operation->operationType);
}

- (NSUInteger)hash
{
    return (NSUInteger)operationType;
}

#pragma mark -

- (BOOL)isAsynchronous
{
    return YES;
}

- (BOOL)isConcurrent
{
    return YES;
}

- (BOOL)isExecuting
{
    return executing;
}

- (BOOL)isFinished
{
    return finished;
}

#pragma mark - Executing

- (void)start
{
    NSLog(@"Start: Operation %@ - added type: %ld", operationUuid, (long)operationType);
}

- (void)runOperation
{
    [self setExecutingState];
    
    switch (operationType) {
        case MTApiOpAuth:
            [self userAuthorization];
            break;
        case MTApiOpObjInfo:
            [self getUserObject];
            break;
        case MTApiOpGetNews:
            [self getNewsFeed];
            break;
        case MTApiOpNewsDetails:
            [self getNewsDetails];
            break;
        case MTApiOpGetNComments:
            [self getNewsComments];
            break;
        case MTApiOpGetServices:
            [self getServices];
            break;
        case MTApiOpAddNewServiceRequest:
            [self addNewServiceRequestForParams];
            break;
        case MTApiOpUploadFile:
            [self uploadFileForParams];
            break;
        default:
            break;
    }
}

- (void)setExecutingState
{
    [self willChangeValueForKey:@"isExecuting"];
    executing = YES;
    [self didChangeValueForKey:@"isExecuting"];
}

- (void)completeOperation
{
    [self willChangeValueForKey:@"isFinished"];
    [self willChangeValueForKey:@"isExecuting"];
    
    executing = NO;
    finished = YES;
    
    [self didChangeValueForKey:@"isExecuting"];
    [self didChangeValueForKey:@"isFinished"];
}

#pragma mark - Requests

- (void)userAuthorization
{
    __weak __typeof(self)weakSelf = self;
    
    [apiClient userAuthorizationForParams:reqParams
                           withCompletion:^(BOOL status, id data, NSString *reason) {
                          
                               [weakSelf callbackWith:status
                                                 data:data
                                              message:reason];
                          
                               [weakSelf completeOperation];
                           }];
}

- (void)getUserObject
{
    __weak __typeof(self)weakSelf = self;
    
    [apiClient getUserObjectInfoForParams:reqParams
                           withCompletion:^(BOOL status, id data, NSString *reason) {
                               
                               [weakSelf callbackWith:status
                                                 data:data
                                              message:reason];
                               
                               [weakSelf completeOperation];
                           }];
}

- (void)getNewsFeed
{
    __weak __typeof(self)weakSelf = self;
    
    [apiClient getNewsFeedForParams:reqParams
                     withCompletion:^(BOOL status, id data, NSString *reason) {
                         
                         [weakSelf callbackWith:status
                                           data:data
                                        message:reason];
                         
                         [weakSelf completeOperation];
                     }];
}

- (void)getNewsDetails
{
    __weak __typeof(self)weakSelf = self;
    
    [apiClient getNewsDetailsForParams:reqParams
                        withCompletion:^(BOOL status, id data, NSString *reason) {
                            
                            [weakSelf callbackWith:status
                                              data:data
                                           message:reason];
                            
                            [weakSelf completeOperation];
                        }];
}

- (void)getNewsComments
{
    __weak __typeof(self)weakSelf = self;
    
    [apiClient getNewsCommentsForParams:reqParams
                         withCompletion:^(BOOL status, id data, NSString *reason) {
                             
                             [weakSelf callbackWith:status
                                               data:data
                                            message:reason];
                             
                             [weakSelf completeOperation];
                         }];
}

- (void)getServices
{
    __weak __typeof(self)weakSelf = self;
    
    [apiClient getServicesForParams:reqParams
                     withCompletion:^(BOOL status, id data, NSString *reason) {
                             
                         [weakSelf callbackWith:status
                                           data:data
                                        message:reason];
                             
                         [weakSelf completeOperation];
                     }];
}

- (void)addNewServiceRequestForParams
{
    __weak __typeof(self)weakSelf = self;
    
    [apiClient addNewServiceRequestForParams:reqParams
                              withCompletion:^(BOOL status, id data, NSString *reason) {
                         
                                  [weakSelf callbackWith:status
                                                    data:data
                                                 message:reason];
                         
                                  [weakSelf completeOperation];
                              }];
}

- (void)uploadFileForParams
{
    __weak __typeof(self)weakSelf = self;
    
    [apiClient uploadFileForParams:reqParams
                    withCompletion:^(BOOL status, id data, NSString *reason) {
                                  
                        [weakSelf callbackWith:status
                                          data:data
                                       message:reason];
                                  
                        [weakSelf completeOperation];
                    }];
}

#pragma mark -

- (void)callbackWith:(BOOL)state data:(id)data message:(NSString *)msg
{
    _handler(state, data, msg);
}

@end
