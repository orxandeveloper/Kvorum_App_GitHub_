//
//  MTCompleteServicesViewController.m
//  Matorin
//
//  Created by Work Inteleks on 9/15/17.
//

#import "MTCompleteServicesViewController.h"
#import "MTClientDataManager.h"

@interface MTCompleteServicesViewController ()
{
    IBOutlet UILabel *addressLabel;
    IBOutlet UILabel *accountLabel;
    
    IBOutlet UILabel *orderNumberLabel;
}

@end

@implementation MTCompleteServicesViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self setupAccountItems];
    [self setupNavBar];
}

- (void)setupNavBar
{
    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    
    self.navigationItem.title = NSLocalizedString(@"Выполнение работ", nil);
    
    UIBarButtonItem *confirm = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Готово", nil)
                                                                style:UIBarButtonItemStyleDone
                                                               target:self
                                                               action:@selector(confirmAction)];
    
    self.navigationItem.rightBarButtonItem = confirm;
    
    self.navigationItem.hidesBackButton = YES;
}

- (void)confirmAction
{
    NSMutableArray *viewControllers = [NSMutableArray arrayWithArray:[[self navigationController] viewControllers]];
    
    [self.navigationController popToViewController:viewControllers[1] animated:YES];
}

- (void)setupAccountItems
{
    addressLabel.text = [CLIENT_DATA_MANAGER getUserAddress];
    accountLabel.text = [CLIENT_DATA_MANAGER getPersonalAccountNumber];
    
    orderNumberLabel.text = [NSString stringWithFormat:NSLocalizedString(@"Номер Вашего заказа: %@", nil), [CLIENT_DATA_MANAGER getOrderServiceNumber]];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
