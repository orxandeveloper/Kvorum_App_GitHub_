//
//  MTOrderServicesTableViewCell.m
//  Matorin
//
//  Created by Work Inteleks on 9/6/17.
//

#import "MTOrderServicesTableViewCell.h"

@implementation MTOrderServicesTableViewCell

@synthesize titleServicesLabel;
@synthesize iconImageView;

- (void)drawRect:(CGRect)rect
{

}

- (void)awakeFromNib
{
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

@end
