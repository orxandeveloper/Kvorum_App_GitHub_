//
//  MTUploadPreviewViewController.h
//  Matorin
//
//  Created by Sergej Bogatenko on 12/22/17.
//  Copyright © 2017 Matorin. All rights reserved.
//

#import "MTBaseViewController.h"

@protocol MTUploadPreviewViewControllerDelegate <NSObject>

@optional
- (void)dismissPreview;
@end

@interface MTUploadPreviewViewController : MTBaseViewController

@property (nonatomic, weak) id <MTUploadPreviewViewControllerDelegate> delegate;

@end
