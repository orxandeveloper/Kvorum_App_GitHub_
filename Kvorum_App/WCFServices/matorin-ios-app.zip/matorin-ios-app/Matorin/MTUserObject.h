//
//  MTUserObject.h
//  Matorin
//
//  Created by Oleg Bogatenko on 11/22/17.
//  Copyright © 2017 Matorin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MTUserObject : NSObject

@property (nonatomic) NSNumber *room;
@property (nonatomic, copy) NSString *address;

+ (MTUserObject *)parseObjectInfoFromServerDict:(NSDictionary *)dict;

@end
