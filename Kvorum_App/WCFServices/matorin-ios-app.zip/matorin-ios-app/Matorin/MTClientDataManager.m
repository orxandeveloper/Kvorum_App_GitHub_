//
//  MTClientDataManager.m
//  Matorin
//
//  Created by Work Inteleks on 9/5/17.
//

#import "MTClientDataManager.h"
#import "MTUser.h"
#import "NSString+Additions.h"

NSString * const MTAuthNotification = @"MTAuthNotification";

@interface MTClientDataManager ()
{
    MTUser *currentUser;
    
    NSMutableArray *orderedServices;
    MTServiceDate *serviceDate;
    
    NSMutableArray *uploadUrlStringsArray;
    NSString *uploadUrlString;
    NSString *serviceComment;
    NSString *serviceOrderNumber;
    UIImage *serviceInfoImg;
}

@end

@implementation MTClientDataManager

+ (MTClientDataManager *)sharedManager
{
    static dispatch_once_t onceToken = 0;
    static id _sharedInstance = nil;
    
    dispatch_once(&onceToken, ^{
        _sharedInstance = [[self alloc] init];
    });
    
    return _sharedInstance;
}

#pragma mark - Init

- (instancetype)init
{
    self = [super init];
    
    if (self)
    {
        if ([MTUser isUserAuthorized])
            currentUser = [MTUser loadCurrentUser];
        
        orderedServices = [NSMutableArray new];
        uploadUrlStringsArray = [NSMutableArray new];
    }
    return self;
}

#pragma mark -

- (void)load
{
    NSLog(@"LOADED: %@", currentUser);
}

#pragma mark - Offer

- (BOOL)isOfferViewed
{
    return [[NSUserDefaults standardUserDefaults] boolForKey:@"showOffer"];
}

- (void)setOfferAsViewed
{
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"showOffer"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

#pragma mark - User

- (BOOL)isAuthorized
{
    if (!currentUser)
        return NO;
    
    return YES;//[MTUser isUserAuthorized];
}

- (NSString *)getUserAuthToken
{
    if (!currentUser)
        return [NSString new];
    
    return [currentUser getAuthToken];
}

- (NSString *)getUserFullName
{
    if (!currentUser.name)
        return NSLocalizedString(@"Name is not defined", nil);
    
    if (![currentUser.name isNotEmpty])
        return NSLocalizedString(@"Name is not defined", nil);
    
    return currentUser.name;
}

- (NSString *)getPersonalAccountNumber
{
    return [NSString stringWithFormat:@"%@", currentUser.accountNumber];
}

- (NSString *)getUserAddress
{
    if (!currentUser.userObject)
        return NSLocalizedString(@"Address is not defined", nil);
    
    return [NSString stringWithFormat:NSLocalizedString(@"Address %@ room %@", nil), currentUser.userObject.address, currentUser.userObject.room];
}

#pragma mark - User Info

- (void)setUserAccountNumber:(NSNumber *)number
          infoFromServerDict:(NSDictionary *)dict
{
    currentUser = [MTUser authorizedUserWithNumber:number
                                           forDict:dict];
    //[self saveAuthorizedUserData];
    
    [self postUserAuthNotification];
}

- (void)setUserObjectInfoFromServerDict:(NSDictionary *)dict
{
    if (!currentUser)
        return;
    
    if (dict)
        currentUser.userObject = [MTUserObject parseObjectInfoFromServerDict:dict];
}

#pragma mark - User Repository

- (void)saveAuthorizedUserData
{
    [MTUser saveInUserDefaults:currentUser];
}

- (void)deactivateCurrentUser
{
    currentUser = nil;
    
    [MTUser kill];
}

#pragma mark - Notifications

- (void)postUserAuthNotification
{
    [[NSNotificationCenter defaultCenter] postNotificationName:MTAuthNotification
                                                        object:self
                                                      userInfo:nil];
}

#pragma mark - Ordered Services

- (void)clearAllServicesInfo
{
    [self clearOrderedServices];
    [self clearOrderedServicesDate];
    
    uploadUrlString = nil;
    serviceComment = nil;
    serviceInfoImg = nil;
    serviceOrderNumber = nil;
    [uploadUrlStringsArray removeAllObjects];
}

- (void)addOrderedService:(MTService *)service
{
    [orderedServices removeAllObjects];
    
    MTService *currentService = service;
    currentService.isCheck = YES;
    
    [orderedServices addObject:currentService];
}

- (void)removeOrderedService:(MTService *)service
{
    if ([orderedServices containsObject:service])
        [orderedServices removeObject:service];
}

- (void)clearOrderedServices
{
    [orderedServices removeAllObjects];
}

- (NSArray<MTService *> *)getOrderedServices
{
    return (NSArray *)orderedServices;
}

- (NSNumber *)getTotalPrice
{
    float totalPrice = 0;
    
    for (MTService *serv in orderedServices)
        totalPrice += [serv.price floatValue] * serv.count;
    
    return @(totalPrice);
}

- (void)setUploadURL:(NSString *)urlString
{
    uploadUrlString = urlString;
    
    [uploadUrlStringsArray addObject:uploadUrlString];
}

- (NSString *)getUploadURLString
{
    uploadUrlString = @"";
    
    for (NSString *str in uploadUrlStringsArray)
        uploadUrlString = [uploadUrlString stringByAppendingString:[uploadUrlString isNotEmpty] ?
                           [NSString stringWithFormat:@", %@", str] : str];
    
    return uploadUrlString;
}

- (NSArray *)getUploadImages
{
    return (NSArray *)uploadUrlStringsArray;
}

#pragma mark - Ordered Services Date

- (void)setupOrderedServicesDate:(MTServiceDate *)date
{
    serviceDate = date;
}

- (MTServiceDate *)getOrderedServicesDate
{
    return serviceDate;
}

- (void)clearOrderedServicesDate
{
    serviceDate = nil;
}

#pragma mark - Ordered Comment/Files

- (void)setupServiceComment:(NSString *)comment
{
    serviceComment = comment;
}

- (NSString *)getServiceComment
{
    return serviceComment;
}

- (void)setupServiceImg:(UIImage *)img
{
    serviceInfoImg = img;
}

- (UIImage *)getServiceImg
{
    return serviceInfoImg;
}

- (NSString *)getBase64ServiceImg
{
    if (serviceInfoImg)
    {
        NSData *data = [UIImagePNGRepresentation(serviceInfoImg) base64EncodedDataWithOptions:NSDataBase64Encoding64CharacterLineLength];

        NSString *base64Sstring = [NSString stringWithUTF8String:[data bytes]];
        
        return [base64Sstring stringByReplacingOccurrencesOfString:@"\r\n" withString:@""];
    }
    
    return nil;
}

- (void)setupOrderServiceNumber:(NSString *)number
{
    serviceOrderNumber = number;
}

- (NSString *)getOrderServiceNumber
{
    return serviceOrderNumber;
}

@end
