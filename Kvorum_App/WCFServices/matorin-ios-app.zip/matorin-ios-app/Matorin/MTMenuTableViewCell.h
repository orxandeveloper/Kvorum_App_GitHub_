//
//  MTMenuTableViewCell.h
//  Matorin
//
//  Created by Work Inteleks on 8/31/17.
//

#import <UIKit/UIKit.h>

@class MTMenuItem;

@interface MTMenuTableViewCell : UITableViewCell

+ (MTMenuTableViewCell *)dequeueForTableView:(UITableView *)tableView
                                   indexPath:(NSIndexPath *)indexPath
                                        item:(MTMenuItem *)item;

@end
