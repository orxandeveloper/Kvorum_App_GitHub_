//
//  MTMenuItem.h
//  Matorin
//
//  Created by Work Inteleks on 8/31/17.
//

#import <Foundation/Foundation.h>

@interface MTMenuItem : NSObject

@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *iconName;
@property (nonatomic, copy) NSString *actionName;
@property (nonatomic, copy) NSString *countText;

@property (nonatomic, assign) BOOL showCountLabel;

@end
